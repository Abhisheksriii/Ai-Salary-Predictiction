#!/usr/bin/env python3
"""
===============================================================================
AURELIUS // PRODUCTION PYTHON FASTAPI BACKEND SERVER
===============================================================================
Module: backend/app.py
Description:
    Standalone production Python HTTP backend integrating:
    - Local Multi-Currency CSV Ingestion & INR Normalization
    - L2-Regularized Multivariate Ridge Regression (salary_engine.py)
    - Gemini LLM Validation & Outlier Interceptor (google-genai SDK)
    - Personalized 3-Horizon Career Trajectory Generator
    - Environment Configuration via python-dotenv (.env)
===============================================================================
"""

import json
import os
from typing import Any, Dict, List, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from salary_engine import (
    FX_RATES_TO_INR,
    add_dataset_record,
    load_and_normalize_dataset,
    run_prediction,
)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")


def build_llm_validation_prompt(profile: Dict[str, Any], reg_output: Dict[str, Any]) -> str:
    """
    Constructs the structured actuarial audit prompt for Gemini LLM to validate
    and, if necessary, intercept and correct unrealistic regression outputs.
    """
    return f"""
You are a Principal Compensation Actuary and AI Career Strategist focusing on Indian (INR) and Global Sovereign tech compensation.

CANDIDATE PROFILE:
- Target Role: {reg_output['effectiveRole']} (Category: {reg_output['category']})
- Employment Status: {profile.get('employmentStatus')} (Student Rule Active: {reg_output['isStudent']})
- Effective Experience: {reg_output['effectiveExperienceYears']} years
- Education Level: {profile.get('educationLevel')}
- Location Tier: {profile.get('locationTier')}
- Company Tier: {profile.get('companyTier')}
- Verified Technical Skills: {', '.join(profile.get('skills', []))}

PYTHON REGRESSION ENGINE OUTPUT:
- Raw Regression Prediction (INR): ₹{reg_output['rawRegressionInr']:,.0f}
- Reference Calibrated Baseline (INR): ₹{reg_output['calibratedBaselineInr']:,.0f}
- Outlier Stress Test Injected: {reg_output['stressTestActive']}

TASK:
1. Validate whether the Raw Regression Prediction (₹{reg_output['rawRegressionInr']:,.0f}) is realistic for this exact profile in INR.
2. If the Raw Regression Prediction deviates unrealistically from market reality (e.g. >25% above/below market norms, Student status receiving senior pay, or Outlier Stress Test active), INTERCEPT and CORRECT it to a realistic INR value.
3. Generate 3 concrete, personalized career development stages (6 Months, 12 Months, 24 Months) with specific technical skills to master, architectural proof-of-work deliverables, and projected INR compensation uplift.
"""
