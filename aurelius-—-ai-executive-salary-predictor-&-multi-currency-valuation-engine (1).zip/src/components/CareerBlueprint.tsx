import React from 'react';
import { ArrowUpRight, Check, Compass, PlusCircle, Sparkles, TrendingUp } from 'lucide-react';
import {
  CandidateProfile,
  formatInrCompact,
  formatInrExact,
  PredictionResponse,
} from '../types/compensation';

interface CareerBlueprintProps {
  profile: CandidateProfile;
  prediction: PredictionResponse | null;
  onAcquireSkillsAndRecalculate: (newSkills: string[]) => void;
}

export const CareerBlueprint: React.FC<CareerBlueprintProps> = ({
  profile,
  prediction,
  onAcquireSkillsAndRecalculate,
}) => {
  const val = prediction?.llmValidation;
  const reg = prediction?.regression;

  const currentInr = val?.validatedInr ?? reg?.calibratedBaselineInr ?? 4091000;
  const roadmap = val?.careerRoadmap ?? [];
  const skillArbitrage = val?.skillArbitrage ?? [];

  const hasAllSkills = (skillsToCheck: string[]) => {
    const lowerCurrent = new Set(profile.skills.map((s) => s.toLowerCase()));
    return skillsToCheck.every((s) => lowerCurrent.has(s.toLowerCase()));
  };

  return (
    <div className="space-y-8">
      {/* HEADER SUMMARY PANEL */}
      <section className="obsidian-panel rounded-2xl p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="font-mono text-xs text-[#4CD7F6] uppercase tracking-wider">
            Personalized AI Career Trajectory &amp; Wealth Arbitrage
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F8FAFC]">
            Concrete Development Paths for {reg?.effectiveRole || profile.role}
          </h2>
          <p className="text-sm text-[#94A3B8] leading-relaxed">
            Synthesized by combining your Python Ridge Regression feature elasticity with Gemini LLM
            actuarial market intelligence. Acquire recommended skills below to simulate real-time INR
            package expansion.
          </p>
        </div>

        <div className="rounded-xl bg-[#090A0F] border border-[#10B981]/30 p-5 shrink-0 space-y-1">
          <div className="font-mono text-xs text-[#94A3B8]">Current Validated Baseline</div>
          <div className="font-mono text-3xl font-bold text-[#4EDEA3] tabular-nums">
            {formatInrCompact(currentInr)}
          </div>
          <div className="font-mono text-xs text-[#64748B] tabular-nums">
            {formatInrExact(currentInr)} · {val?.marketPositioning || 'Sovereign Tier'}
          </div>
        </div>
      </section>

      {/* 3-HORIZON CONCRETE DEVELOPMENT ROADMAP */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-[#F8FAFC]">
              01. Three-Horizon Career Elevation Roadmap
            </h3>
            <p className="text-xs text-[#94A3B8]">
              Actionable milestones, proof-of-work deliverables, and projected INR total compensation
            </p>
          </div>
          <Compass className="w-5 h-5 text-[#10B981]" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {roadmap.map((stage, idx) => {
            const alreadyAcquired = hasAllSkills(stage.coreSkillsToAcquire);
            return (
              <div
                key={stage.horizon || idx}
                className="obsidian-panel rounded-2xl p-6 flex flex-col justify-between space-y-6"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <span className="font-mono text-xs font-semibold text-[#4CD7F6]">
                      {stage.horizon}
                    </span>
                    <span className="font-mono text-xs font-semibold text-[#4EDEA3] tabular-nums">
                      +{formatInrCompact(stage.deltaInr)}
                    </span>
                  </div>

                  <div>
                    <div className="text-xs text-[#94A3B8] font-mono">Target Elevation Role</div>
                    <div className="text-lg font-bold text-[#F8FAFC] mt-0.5">
                      {stage.targetRole}
                    </div>
                  </div>

                  <div className="rounded-xl bg-[#090A0F] border border-white/10 p-4 flex items-baseline justify-between">
                    <span className="font-mono text-xs text-[#94A3B8]">Projected CTC (INR)</span>
                    <div className="text-right">
                      <div className="font-mono text-xl font-bold text-[#F8FAFC] tabular-nums">
                        {formatInrCompact(stage.projectedInr)}
                      </div>
                      <div className="font-mono text-[11px] text-[#64748B] tabular-nums">
                        {formatInrExact(stage.projectedInr)}
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="font-mono text-xs text-[#94A3B8] mb-1.5">
                      Required High-Leverage Capabilities:
                    </div>
                    <div className="font-mono text-xs text-[#FFB95F]">
                      {stage.coreSkillsToAcquire.join(' · ')}
                    </div>
                  </div>

                  <div>
                    <div className="font-mono text-xs text-[#94A3B8] mb-1">
                      Concrete Proof-of-Work Deliverable:
                    </div>
                    <p className="text-xs text-[#E3E1E9] leading-relaxed">
                      {stage.concreteDeliverable}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onAcquireSkillsAndRecalculate(stage.coreSkillsToAcquire)}
                  disabled={alreadyAcquired}
                  className={`w-full py-2.5 px-4 rounded-xl font-mono text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                    alreadyAcquired
                      ? 'bg-white/[0.04] border border-white/10 text-[#64748B] cursor-default'
                      : 'bg-[#06B6D4]/15 border border-[#06B6D4] text-[#4CD7F6] hover:bg-[#06B6D4] hover:text-[#090A0F] cursor-pointer'
                  }`}
                >
                  {alreadyAcquired ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Skills Already in Active Stack</span>
                    </>
                  ) : (
                    <>
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>Acquire Stage Skills &amp; Simulate</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* SKILL ARBITRAGE MATRIX & EXECUTIVE NEGOTIATION PLAYBOOK */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-8 obsidian-panel rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h3 className="text-base font-semibold text-[#F8FAFC]">
                02. High-Margin Skill Arbitrage Matrix
              </h3>
              <p className="text-xs text-[#94A3B8]">
                Highest marginal INR compensation multipliers missing from your current skill stack
              </p>
            </div>
            <TrendingUp className="w-4 h-4 text-[#4EDEA3]" />
          </div>

          <div className="space-y-3">
            {skillArbitrage.map((item) => {
              const isEquipped = profile.skills.some(
                (s) => s.toLowerCase() === item.skillName.toLowerCase()
              );
              return (
                <div
                  key={item.skillName}
                  className="rounded-xl bg-[#090A0F] border border-white/10 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-sm font-bold text-[#F8FAFC]">
                        {item.skillName}
                      </span>
                      <span className="font-mono text-xs text-[#4EDEA3] tabular-nums">
                        +{item.upliftPercentage}% (+{formatInrCompact(item.estimatedInrUplift)})
                      </span>
                    </div>
                    <p className="text-xs text-[#94A3B8] leading-relaxed">
                      {item.marketRationale}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => onAcquireSkillsAndRecalculate([item.skillName])}
                    disabled={isEquipped}
                    className={`px-3.5 py-2 rounded-lg font-mono text-xs font-semibold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-colors ${
                      isEquipped
                        ? 'bg-white/5 text-[#64748B] cursor-default'
                        : 'bg-[#10B981]/15 border border-[#10B981] text-[#4EDEA3] hover:bg-[#10B981] hover:text-[#090A0F] cursor-pointer'
                    }`}
                  >
                    {isEquipped ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Equipped</span>
                      </>
                    ) : (
                      <>
                        <span>Inject Skill</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        {/* EXECUTIVE NEGOTIATION LEVER */}
        <section className="lg:col-span-4 obsidian-panel rounded-2xl p-6 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-semibold text-[#F8FAFC]">
                03. Executive Negotiation Lever
              </h3>
              <Sparkles className="w-4 h-4 text-[#FFB95F]" />
            </div>

            <div className="gold-capsule rounded-xl p-4 space-y-2">
              <div className="font-mono text-xs font-semibold text-[#FFB95F] uppercase tracking-wider">
                Strategic Anchor Directive
              </div>
              <p className="text-xs text-[#E3E1E9] leading-relaxed">
                {val?.executiveNegotiationLever ||
                  'Anchor total compensation discussions on verified P75 sovereign benchmarks and negotiate performance-linked RSU vesting.'}
              </p>
            </div>

            <div className="space-y-2 text-xs text-[#94A3B8]">
              <div className="font-mono text-[#F8FAFC] font-medium">
                Key Compensation Structuring Notes:
              </div>
              <p className="leading-relaxed">
                1. Target a minimum of {reg?.componentSplit.equityPct ?? 20}% annual equity/RSU
                allocation to capture compound valuation upside.
              </p>
              <p className="leading-relaxed">
                2. Benchmark base salary against INR-normalized global engineering hubs rather than
                legacy domestic service bands.
              </p>
            </div>
          </div>

          <div className="rounded-xl bg-[#090A0F] border border-white/10 p-3.5 font-mono text-xs text-[#94A3B8] flex items-center justify-between tabular-nums">
            <span>P75 Negotiation Target:</span>
            <span className="text-[#4EDEA3] font-bold">
              {formatInrCompact(reg?.percentileBandsInr.p75 ?? currentInr * 1.15)}
            </span>
          </div>
        </section>
      </div>
    </div>
  );
};
