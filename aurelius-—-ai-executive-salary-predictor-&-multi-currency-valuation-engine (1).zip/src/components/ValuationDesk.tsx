import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Cpu,
  ExternalLink,
  Globe,
  History,
  IndianRupee,
  Lock,
  MapPin,
  Plus,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Sliders,
  Sparkles,
  TrendingUp,
  X,
} from 'lucide-react';
import {
  CandidateProfile,
  CompanyTier,
  EducationLevel,
  EmploymentStatus,
  formatInrCompact,
  formatInrExact,
  formatSovereignCurrency,
  IndianCity,
  LiveMarketPulseResponse,
  MLModelType,
  PredictionResponse,
  ROLE_CATALOG_BY_CATEGORY,
  RoleCategory,
  SKILL_CATALOG,
} from '../types/compensation';

interface ValuationDeskProps {
  profile: CandidateProfile;
  onUpdateProfile: (updater: (prev: CandidateProfile) => CandidateProfile) => void;
  prediction: PredictionResponse | null;
  isLoading: boolean;
  onRunPrediction: (customProfile?: CandidateProfile) => void;
  onNavigateTab: (tab: 'desk' | 'blueprint' | 'ledger' | 'engine') => void;
  marketPulse: LiveMarketPulseResponse | null;
  isLoadingPulse: boolean;
  onFetchLivePulse: () => void;
  onResetSession: () => void;
}

const EMPLOYMENT_STATUSES: EmploymentStatus[] = [
  'Full-Time Professional',
  'Executive / Director',
  'Student',
  'Freelance / Consultant',
  'Career Transition',
];

const EDUCATION_LEVELS: EducationLevel[] = [
  'High School / Bootcamp',
  "Bachelor's (B.Tech / B.Sc)",
  "Master's (M.Tech / MS / MBA)",
  'Ph.D. / Doctorate',
];

const INDIAN_CITIES: IndianCity[] = [
  'Bengaluru',
  'Hyderabad',
  'Mumbai',
  'Delhi NCR (Gurugram/Noida)',
  'Pune',
  'Chennai',
  'Ahmedabad / GIFT City / Kochi',
  'Remote India (Global Entity)',
];

const COMPANY_TIERS: CompanyTier[] = [
  'Enterprise IT & Digital Consulting',
  'High-Growth AI / SaaS Startup',
  'Global Capability Center (GCC India)',
  'Indian Tech Unicorn / Decacorn',
  'MAANG / Tier-1 Global Product',
];

const ML_MODELS: MLModelType[] = [
  'Stacked Meta-Ensemble',
  'Gradient Boosting (GBDT)',
  'Random Forest Regressor',
  'L2 Ridge Regression',
];

const SOVEREIGN_CURRENCIES = ['USD', 'EUR', 'GBP', 'SGD', 'AED', 'CHF', 'CAD', 'AUD', 'JPY'];

export const ValuationDesk: React.FC<ValuationDeskProps> = ({
  profile,
  onUpdateProfile,
  prediction,
  isLoading,
  onRunPrediction,
  onNavigateTab,
  marketPulse,
  isLoadingPulse,
  onFetchLivePulse,
  onResetSession,
}) => {
  const [customSkillInput, setCustomSkillInput] = useState('');
  const [selectedForeignCurrency, setSelectedForeignCurrency] = useState<string>('USD');
  const [rememberedExperience, setRememberedExperience] = useState<number>(
    profile.experienceYears > 0 ? profile.experienceYears : 3
  );

  const isStudent = profile.employmentStatus === 'Student';
  const isOtherRole = profile.role === 'Other';

  const handleStatusChange = (newStatus: EmploymentStatus) => {
    onUpdateProfile((prev) => {
      if (newStatus === 'Student') {
        if (prev.experienceYears > 0) {
          setRememberedExperience(prev.experienceYears);
        }
        return {
          ...prev,
          employmentStatus: 'Student',
          experienceYears: 0,
        };
      } else {
        const restoredExp = prev.employmentStatus === 'Student' ? rememberedExperience : prev.experienceYears;
        return {
          ...prev,
          employmentStatus: newStatus,
          experienceYears: restoredExp,
        };
      }
    });
  };

  const handleCityChange = (city: IndianCity) => {
    const derivedLocTier =
      city === 'Remote India (Global Entity)'
        ? 'Remote Sovereign Global'
        : city === 'Pune' || city === 'Chennai' || city === 'Ahmedabad / GIFT City / Kochi'
          ? 'Tier 2 Emerging Tech Hub'
          : 'Tier 1 India Metro';

    onUpdateProfile((prev) => ({
      ...prev,
      indianCity: city,
      locationTier: derivedLocTier,
    }));
  };

  const handleRoleChange = (value: string) => {
    if (value === 'Other') {
      onUpdateProfile((prev) => ({
        ...prev,
        role: 'Other',
        customRoleTitle: prev.customRoleTitle || 'AI Systems & Governance Lead',
      }));
      return;
    }

    let matchedCategory: RoleCategory = profile.category;
    for (const [cat, roles] of Object.entries(ROLE_CATALOG_BY_CATEGORY)) {
      if (roles.includes(value)) {
        matchedCategory = cat as RoleCategory;
        break;
      }
    }

    onUpdateProfile((prev) => ({
      ...prev,
      role: value,
      category: matchedCategory,
    }));
  };

  const handleAddCustomSkill = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = customSkillInput.trim();
    if (!trimmed) return;
    onUpdateProfile((prev) => {
      if (prev.skills.some((s) => s.toLowerCase() === trimmed.toLowerCase())) {
        return prev;
      }
      return {
        ...prev,
        skills: [...prev.skills, trimmed],
      };
    });
    setCustomSkillInput('');
  };

  const handleToggleSkill = (skillName: string) => {
    onUpdateProfile((prev) => {
      const exists = prev.skills.some((s) => s.toLowerCase() === skillName.toLowerCase());
      if (exists) {
        return {
          ...prev,
          skills: prev.skills.filter((s) => s.toLowerCase() !== skillName.toLowerCase()),
        };
      }
      return {
        ...prev,
        skills: [...prev.skills, skillName],
      };
    });
  };

  const reg = prediction?.regression;
  const val = prediction?.llmValidation;

  const finalInr = val?.validatedInr ?? reg?.calibratedBaselineInr ?? 1812000;
  const rawInr = val?.rawRegressionInr ?? reg?.rawRegressionInr ?? 1812000;
  const avgBreakdown = reg?.realLifeAverageBreakdown;
  const sessionStats = reg?.sessionOutcomeTelemetry;

  const fxMap = reg?.fxRatesToInr ?? {
    INR: 1,
    USD: 86.45,
    EUR: 93.2,
    GBP: 110.85,
    SGD: 64.5,
    AED: 23.54,
    CHF: 98.1,
    CAD: 61.8,
    AUD: 56.15,
    JPY: 0.58,
  };
  const selectedFxRate = fxMap[selectedForeignCurrency] || 86.45;
  const convertedForeignValue = finalInr / selectedFxRate;

  const taxInfo = reg?.indianTaxBreakdown;
  const baseInr = taxInfo?.annualBaseInr ?? Math.round(finalInr * ((reg?.componentSplit.basePct ?? 78) / 100));
  const bonusInr = taxInfo?.annualBonusInr ?? Math.round(finalInr * ((reg?.componentSplit.bonusPct ?? 12) / 100));
  const equityInr = taxInfo?.annualEquityInr ?? Math.round(finalInr * ((reg?.componentSplit.equityPct ?? 10) / 100));
  const monthlyInHandInr = taxInfo?.monthlyInHandInr ?? Math.round((baseInr * 0.85) / 12);

  return (
    <div className="space-y-6">
      {/* SESSION AVERAGE ESTIMATED OUTCOME TRACKER BAR */}
      <section className="obsidian-panel rounded-2xl p-5 border-[#06B6D4]/30">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 font-mono text-xs text-[#4CD7F6]">
              <History className="w-4 h-4 text-[#06B6D4]" />
              <span>
                LIVE SESSION AVERAGE ESTIMATED OUTCOME ({sessionStats?.sessionSimulationCount ?? 1}{' '}
                {sessionStats?.sessionSimulationCount === 1 ? 'Estimation' : 'Estimations'} in Session)
              </span>
            </div>
            <p className="text-xs text-[#94A3B8]">
              Tracks every scenario you test in this session and computes a real-life average outcome
              benchmarked against AmbitionBox, Naukri &amp; Glassdoor India medians.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 shrink-0">
            <div className="rounded-xl bg-[#090A0F] border border-[#10B981]/35 px-3.5 py-2.5">
              <div className="font-mono text-[10px] text-[#94A3B8] uppercase">
                Session Avg Outcome
              </div>
              <div className="font-mono text-lg font-bold text-[#4EDEA3] tabular-nums">
                {formatInrCompact(sessionStats?.sessionAverageCtcInr || finalInr)}
              </div>
              <div className="font-mono text-[10px] text-[#64748B] tabular-nums">
                {formatInrExact(sessionStats?.sessionAverageCtcInr || finalInr)}/yr
              </div>
            </div>

            <div className="rounded-xl bg-[#090A0F] border border-white/10 px-3.5 py-2.5">
              <div className="font-mono text-[10px] text-[#94A3B8] uppercase">
                Session Avg In-Hand
              </div>
              <div className="font-mono text-lg font-bold text-[#F8FAFC] tabular-nums">
                {formatInrExact(sessionStats?.sessionAverageMonthlyInHandInr || monthlyInHandInr)}
              </div>
              <div className="font-mono text-[10px] text-[#4CD7F6] tabular-nums">
                per month (post-tax)
              </div>
            </div>

            <div className="rounded-xl bg-[#090A0F] border border-white/10 px-3.5 py-2.5">
              <div className="font-mono text-[10px] text-[#94A3B8] uppercase">
                Session Min — Max
              </div>
              <div className="font-mono text-sm font-semibold text-[#FFB95F] mt-0.5 tabular-nums">
                {formatInrCompact(sessionStats?.sessionMinCtcInr || finalInr)} –{' '}
                {formatInrCompact(sessionStats?.sessionMaxCtcInr || finalInr)}
              </div>
              <div className="font-mono text-[10px] text-[#64748B]">
                All-India Median: ₹11.80 L
              </div>
            </div>

            <div className="flex flex-col justify-center">
              <button
                type="button"
                onClick={onResetSession}
                className="h-full px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/15 font-mono text-xs text-[#94A3B8] hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5 text-[#4CD7F6]" />
                <span>Reset Session Avg</span>
              </button>
            </div>
          </div>
        </div>

        {/* Session Simulation History Trail */}
        {sessionStats && sessionStats.sessionHistory && sessionStats.sessionHistory.length > 0 && (
          <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-2 overflow-x-auto pb-1">
            <span className="font-mono text-[11px] text-[#64748B] shrink-0">
              Recent Session Estimations:
            </span>
            {sessionStats.sessionHistory.map((item, idx) => (
              <div
                key={`${item.timestamp}-${idx}`}
                className="px-2.5 py-1 rounded-lg bg-[#090A0F] border border-white/10 font-mono text-[11px] text-[#E3E1E9] whitespace-nowrap shrink-0 tabular-nums"
              >
                <span className="text-[#94A3B8]">#{sessionStats.sessionHistory.length - idx}</span>{' '}
                <span>{item.role}</span> · <span className="text-[#4CD7F6]">{item.indianCity}</span> (
                {item.experienceYears}y) →{' '}
                <strong className="text-[#4EDEA3]">{formatInrCompact(item.estimatedCtcInr)}</strong> (
                {formatInrExact(item.monthlyInHandInr)}/mo)
              </div>
            ))}
          </div>
        )}
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT 5 COLUMNS: REAL-TIME INDIA & ML PARAMETER CONTROLS */}
        <section className="lg:col-span-5 obsidian-panel rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-white/10 pb-3.5">
            <div>
              <h2 className="text-lg font-semibold tracking-tight text-[#F8FAFC]">
                India Real-Time ML Parameter Console
              </h2>
              <p className="text-xs text-[#94A3B8] mt-0.5">
                Calibrated to real-life 2026 Indian salaries (AmbitionBox, Naukri &amp; Glassdoor)
              </p>
            </div>
            <Sliders className="w-4 h-4 text-[#06B6D4] shrink-0" />
          </div>

          {/* 1. MACHINE LEARNING ALGORITHM SELECTOR */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-mono text-xs font-medium text-[#94A3B8] flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-[#4CD7F6]" />
                <span>01. Active Python ML Algorithm</span>
              </label>
              <span className="font-mono text-[11px] text-[#4EDEA3]">PPP-Normalized Fit</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {ML_MODELS.map((modelName) => {
                const active = profile.mlModel === modelName;
                return (
                  <button
                    key={modelName}
                    type="button"
                    onClick={() => onUpdateProfile((prev) => ({ ...prev, mlModel: modelName }))}
                    className={`px-3 py-2 rounded-lg text-xs font-mono text-left transition-all truncate cursor-pointer ${
                      active
                        ? 'bg-[#06B6D4]/20 border border-[#06B6D4] text-[#4CD7F6] font-semibold'
                        : 'bg-white/[0.02] border border-white/10 text-[#94A3B8] hover:border-white/25 hover:text-[#F8FAFC]'
                    }`}
                  >
                    {modelName}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. EMPLOYMENT STATUS (WITH STUDENT CONDITIONAL LOGIC) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-mono text-xs font-medium text-[#94A3B8]">
                02. Employment Status
              </label>
              <span className="font-mono text-xs text-[#4CD7F6]">
                {isStudent ? 'India Campus / Fresher Lock' : 'Active Professional'}
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {EMPLOYMENT_STATUSES.map((status) => {
                const active = profile.employmentStatus === status;
                return (
                  <button
                    key={status}
                    type="button"
                    onClick={() => handleStatusChange(status)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium text-left transition-all whitespace-nowrap truncate cursor-pointer ${
                      active
                        ? 'bg-[#10B981]/15 border border-[#10B981] text-[#4EDEA3]'
                        : 'bg-white/[0.02] border border-white/10 text-[#94A3B8] hover:border-white/25 hover:text-[#F8FAFC]'
                    }`}
                  >
                    {status}
                  </button>
                );
              })}
            </div>

            {isStudent && (
              <div className="rounded-lg bg-[#06B6D4]/[0.07] border border-[#06B6D4]/35 p-3 flex items-start gap-2.5">
                <Lock className="w-4 h-4 text-[#4CD7F6] shrink-0 mt-0.5" />
                <div className="text-xs leading-relaxed text-[#E3E1E9]">
                  <span className="font-mono font-semibold text-[#4CD7F6]">
                    [STUDENT_GUARDRAIL_ACTIVE]
                  </span>{' '}
                  Experience field is disabled and clamped to{' '}
                  <span className="font-mono font-semibold text-white">0.0 yrs</span>. Evaluating
                  relatable Indian Campus Placement / Fresher &amp; Internship CTC bands in{' '}
                  {profile.indianCity} (typically ₹3.5L – ₹12.5L).
                </div>
              </div>
            )}
          </div>

          {/* 3. INDIAN TECH HUB CITY SELECTOR */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-mono text-xs font-medium text-[#94A3B8] flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#10B981]" />
                <span>03. Indian Tech Hub / Metro Location</span>
              </label>
              <span className="font-mono text-[11px] text-[#94A3B8]">{profile.locationTier}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {INDIAN_CITIES.map((city) => {
                const active = profile.indianCity === city;
                return (
                  <button
                    key={city}
                    type="button"
                    onClick={() => handleCityChange(city)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium text-left transition-all truncate cursor-pointer ${
                      active
                        ? 'bg-[#10B981]/15 border border-[#10B981] text-[#4EDEA3]'
                        : 'bg-white/[0.02] border border-white/10 text-[#94A3B8] hover:border-white/25 hover:text-[#F8FAFC]'
                    }`}
                  >
                    {city}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. EXTENSIVE JOB ROLE SELECTION + CUSTOMIZED 'OTHER' CATEGORY */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label htmlFor="role-select" className="font-mono text-xs font-medium text-[#94A3B8]">
                04. Target Job Role Architecture
              </label>
              <span className="text-xs text-[#94A3B8]">{profile.category}</span>
            </div>

            <select
              id="role-select"
              value={profile.role}
              onChange={(e) => handleRoleChange(e.target.value)}
              className="w-full rounded-lg bg-[#090A0F] border border-white/15 px-3.5 py-2.5 text-sm font-mono text-[#F8FAFC] focus:border-[#10B981] focus:outline-none transition-colors"
            >
              {Object.entries(ROLE_CATALOG_BY_CATEGORY).map(([catName, roles]) => (
                <optgroup key={catName} label={catName} className="bg-[#0D0F17] text-[#94A3B8]">
                  {roles.map((r) => (
                    <option key={r} value={r} className="bg-[#090A0F] text-[#F8FAFC]">
                      {r}
                    </option>
                  ))}
                </optgroup>
              ))}
              <optgroup label="Custom Role Specification" className="bg-[#0D0F17] text-[#F59E0B]">
                <option value="Other" className="bg-[#090A0F] text-[#FFB95F]">
                  Other (Specify Custom Role &amp; Domain)
                </option>
              </optgroup>
            </select>

            {isOtherRole && (
              <div className="rounded-xl bg-white/[0.02] border border-[#F59E0B]/35 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-semibold text-[#FFB95F]">
                    Custom Role Calibration Matrix
                  </span>
                  <span className="font-mono text-xs text-[#94A3B8]">
                    Complexity: {profile.customComplexity.toFixed(2)}x
                  </span>
                </div>

                <div>
                  <label className="block font-mono text-xs text-[#94A3B8] mb-1">
                    Custom Job Role Title
                  </label>
                  <input
                    type="text"
                    value={profile.customRoleTitle}
                    onChange={(e) =>
                      onUpdateProfile((prev) => ({ ...prev, customRoleTitle: e.target.value }))
                    }
                    placeholder="e.g., Agentic AI Engineer, BI Analytics Lead"
                    className="w-full rounded-lg bg-[#090A0F] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC] focus:border-[#F59E0B] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-mono text-xs text-[#94A3B8] mb-1">
                      Benchmark Domain Category
                    </label>
                    <select
                      value={profile.category}
                      onChange={(e) =>
                        onUpdateProfile((prev) => ({
                          ...prev,
                          category: e.target.value as RoleCategory,
                        }))
                      }
                      className="w-full rounded-lg bg-[#090A0F] border border-white/15 px-2.5 py-2 text-xs font-mono text-[#F8FAFC] focus:border-[#F59E0B] focus:outline-none"
                    >
                      {Object.keys(ROLE_CATALOG_BY_CATEGORY).map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-mono text-xs text-[#94A3B8] mb-1">
                      Scope Multiplier ({profile.customComplexity.toFixed(2)}x)
                    </label>
                    <input
                      type="range"
                      min={0.75}
                      max={1.65}
                      step={0.05}
                      value={profile.customComplexity}
                      onChange={(e) =>
                        onUpdateProfile((prev) => ({
                          ...prev,
                          customComplexity: parseFloat(e.target.value),
                        }))
                      }
                      className="w-full cyber-slider mt-2"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 5. EXPERIENCE FIELD (DISABLED WHEN 'STUDENT' IS SELECTED) */}
          <div
            className={`space-y-2.5 rounded-xl p-3.5 border transition-all ${
              isStudent
                ? 'bg-[#090A0F]/60 border-white/5 opacity-60'
                : 'bg-white/[0.015] border-white/10'
            }`}
          >
            <div className="flex items-center justify-between">
              <label
                htmlFor="experience-slider"
                className="font-mono text-xs font-medium text-[#94A3B8] flex items-center gap-1.5"
              >
                <span>05. Verified Experience Tenure</span>
                {isStudent && <Lock className="w-3.5 h-3.5 text-[#4CD7F6]" />}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  max={30}
                  step={0.5}
                  disabled={isStudent}
                  aria-label="Experience in years"
                  value={isStudent ? 0 : profile.experienceYears}
                  onChange={(e) => {
                    const valNum = Math.max(0, Math.min(30, Number(e.target.value) || 0));
                    setRememberedExperience(valNum);
                    onUpdateProfile((prev) => ({ ...prev, experienceYears: valNum }));
                  }}
                  className="w-16 text-right rounded bg-[#090A0F] border border-white/15 px-2 py-1 font-mono text-xs font-semibold text-[#4EDEA3] disabled:text-[#64748B] disabled:cursor-not-allowed focus:border-[#10B981] focus:outline-none tabular-nums"
                />
                <span className="font-mono text-xs text-[#94A3B8]">yrs</span>
              </div>
            </div>

            <input
              id="experience-slider"
              type="range"
              min={0}
              max={25}
              step={1}
              disabled={isStudent}
              value={isStudent ? 0 : profile.experienceYears}
              onChange={(e) => {
                const valNum = Number(e.target.value);
                setRememberedExperience(valNum);
                onUpdateProfile((prev) => ({ ...prev, experienceYears: valNum }));
              }}
              className="w-full cyber-slider"
            />

            <div className="flex justify-between font-mono text-[11px] text-[#64748B] tabular-nums">
              <span>0 yrs (Fresher)</span>
              <span>3 yrs (Mid-Level)</span>
              <span>8 yrs (Lead/Architect)</span>
              <span>18+ yrs (VP/CXO)</span>
            </div>
          </div>

          {/* 6. ACADEMIC CREDENTIAL & INDIAN ORGANIZATION TIER */}
          <div className="space-y-3">
            <div>
              <label className="block font-mono text-xs font-medium text-[#94A3B8] mb-1.5">
                06. Academic Credential
              </label>
              <select
                value={profile.educationLevel}
                onChange={(e) =>
                  onUpdateProfile((prev) => ({
                    ...prev,
                    educationLevel: e.target.value as EducationLevel,
                  }))
                }
                className="w-full rounded-lg bg-[#090A0F] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC] focus:border-[#10B981] focus:outline-none"
              >
                {EDUCATION_LEVELS.map((edu) => (
                  <option key={edu} value={edu}>
                    {edu}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-mono text-xs font-medium text-[#94A3B8] mb-1.5">
                07. Indian Employer Ecosystem Tier
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                {COMPANY_TIERS.map((tier) => {
                  const active = profile.companyTier === tier;
                  return (
                    <button
                      key={tier}
                      type="button"
                      onClick={() => onUpdateProfile((prev) => ({ ...prev, companyTier: tier }))}
                      className={`px-3 py-2 rounded-lg text-xs font-medium text-left transition-all truncate cursor-pointer ${
                        active
                          ? 'bg-[#06B6D4]/15 border border-[#06B6D4] text-[#4CD7F6]'
                          : 'bg-white/[0.02] border border-white/10 text-[#94A3B8] hover:border-white/25 hover:text-[#F8FAFC]'
                      }`}
                    >
                      {tier}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 7. DEDICATED USER SKILLS INPUT & MARGINAL PREMIUM MATRIX */}
          <div className="space-y-3 border-t border-white/10 pt-4">
            <div className="flex items-center justify-between">
              <label className="font-mono text-xs font-medium text-[#94A3B8]">
                08. Verified Technical Skills ({profile.skills.length})
              </label>
              <span className="font-mono text-xs text-[#4EDEA3]">Live ML Feature Vector</span>
            </div>

            <form onSubmit={handleAddCustomSkill} className="flex gap-2">
              <input
                type="text"
                value={customSkillInput}
                onChange={(e) => setCustomSkillInput(e.target.value)}
                placeholder="Add custom skill (e.g., Spring Boot, PowerBI, LangGraph)..."
                className="flex-1 rounded-lg bg-[#090A0F] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC] placeholder:text-[#64748B] focus:border-[#10B981] focus:outline-none"
              />
              <button
                type="submit"
                className="px-3.5 py-2 rounded-lg bg-white/[0.06] border border-white/15 hover:border-[#06B6D4] text-xs font-mono font-medium text-[#F8FAFC] flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-[#4CD7F6]" />
                Add Skill
              </button>
            </form>

            <div className="flex flex-wrap gap-1.5">
              {profile.skills.map((skill) => (
                <button
                  key={skill}
                  type="button"
                  onClick={() => handleToggleSkill(skill)}
                  title="Click to remove skill"
                  className="px-2.5 py-1 rounded-md bg-[#10B981]/15 border border-[#10B981]/50 text-xs font-mono text-[#4EDEA3] flex items-center gap-1.5 hover:bg-[#F43F5E]/15 hover:border-[#F43F5E]/50 hover:text-[#FFB4AB] transition-colors cursor-pointer"
                >
                  <span>{skill}</span>
                  <X className="w-3 h-3" />
                </button>
              ))}
            </div>

            <div className="pt-1">
              <div className="text-[11px] font-mono text-[#64748B] mb-2">
                Quick-Toggle Indian Market High-Demand Skills:
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                {SKILL_CATALOG.map((item) => {
                  const isSelected = profile.skills.some(
                    (s) => s.toLowerCase() === item.name.toLowerCase()
                  );
                  return (
                    <button
                      key={item.name}
                      type="button"
                      onClick={() => handleToggleSkill(item.name)}
                      className={`px-2 py-1 rounded text-[11px] font-mono transition-colors whitespace-nowrap cursor-pointer ${
                        isSelected
                          ? 'bg-[#06B6D4]/20 border border-[#06B6D4] text-[#4CD7F6]'
                          : 'bg-[#090A0F] border border-white/10 text-[#94A3B8] hover:border-white/25 hover:text-[#F8FAFC]'
                      }`}
                    >
                      {item.name} <span className="text-[#10B981]">+{item.premiumPct}%</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 8. OUTLIER STRESS TEST TOGGLE */}
          <div className="rounded-xl bg-[#090A0F] border border-white/10 p-3.5 flex items-center justify-between gap-3">
            <div>
              <div className="font-mono text-xs font-medium text-[#F8FAFC]">
                Simulate Uncalibrated ML Outlier (2.85x Runaway)
              </div>
              <div className="text-xs text-[#94A3B8] mt-0.5">
                Tests Gemini LLM Validation Interceptor against unrealistic predictions
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={profile.stressTestAnomaly}
              onClick={() =>
                onUpdateProfile((prev) => ({
                  ...prev,
                  stressTestAnomaly: !prev.stressTestAnomaly,
                }))
              }
              className={`px-3 py-1.5 rounded-lg font-mono text-xs font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                profile.stressTestAnomaly
                  ? 'bg-[#F43F5E]/20 border border-[#F43F5E] text-[#FFB4AB]'
                  : 'bg-white/[0.04] border border-white/15 text-[#94A3B8] hover:text-white'
              }`}
            >
              {profile.stressTestAnomaly ? 'Stress Test: ON' : 'Stress Test: OFF'}
            </button>
          </div>

          <button
            type="button"
            onClick={() => onRunPrediction()}
            disabled={isLoading}
            className="w-full py-3.5 px-5 rounded-xl bg-[#10B981] hover:bg-[#34D399] text-[#090A0F] font-mono text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Computing Real-Life India ML Average...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Compute Relatable Real-Life Outcome</span>
              </>
            )}
          </button>
        </section>

        {/* RIGHT 7 COLUMNS: REAL-LIFE AVERAGE ESTIMATED OUTCOME, IN-HAND SALARY & ML ENSEMBLE */}
        <section className="lg:col-span-7 space-y-6">
          {/* PRIMARY VALUATION HERO PANEL */}
          <div className="obsidian-panel rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div className="text-xs text-[#94A3B8] font-mono">
                <span className="text-[#F8FAFC] font-semibold">{reg?.effectiveRole || profile.role}</span>
                <span className="mx-2 text-white/30">·</span>
                <span className="text-[#4EDEA3]">{profile.indianCity}, India</span>
                <span className="mx-2 text-white/30">·</span>
                <span>{isStudent ? '0.0 Yrs (Student/Fresher)' : `${profile.experienceYears} Yrs`}</span>
              </div>

              <div className="font-mono text-xs text-[#4CD7F6] tabular-nums">
                {reg?.selectedMlModel || profile.mlModel} · R² = {reg?.modelMetrics.r2Score ?? 0.9645}
              </div>
            </div>

            {/* MAIN MONETARY READOUT & LIVE FX CONVERSION CAPSULE */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-end">
              <div className="md:col-span-7 space-y-2">
                <div className="font-mono text-xs text-[#4EDEA3] uppercase tracking-wider">
                  Average Estimated Outcome (Real-Life India CTC)
                </div>
                <div className="font-mono text-4xl sm:text-5xl font-bold tracking-tight text-[#F8FAFC] tabular-nums">
                  {formatInrCompact(finalInr)}
                  <span className="text-lg font-normal text-[#94A3B8] ml-2">per annum</span>
                </div>
                <div className="font-mono text-xs text-[#94A3B8] tabular-nums">
                  Realistic Expected Range:{' '}
                  <span className="text-[#F8FAFC] font-semibold">
                    {formatInrCompact(avgBreakdown?.realisticLowInr ?? finalInr * 0.78)} —{' '}
                    {formatInrCompact(avgBreakdown?.realisticHighInr ?? finalInr * 1.24)}
                  </span>{' '}
                  ({formatInrExact(finalInr)})
                </div>
                <div className="pt-1 flex items-center gap-2 font-mono text-xs text-[#4CD7F6] tabular-nums">
                  <IndianRupee className="w-3.5 h-3.5 text-[#10B981]" />
                  <span>
                    Relatable Monthly In-Hand Salary (Post-Tax &amp; EPF):{' '}
                    <strong className="text-white text-sm">
                      {formatInrExact(monthlyInHandInr)} / month
                    </strong>
                  </span>
                </div>
              </div>

              {/* 2-TONE IMPERIAL GOLD LIVE FX MULTI-CURRENCY CAPSULE */}
              <div className="md:col-span-5 gold-capsule rounded-xl p-4 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] font-semibold text-[#FFB95F] uppercase tracking-wider">
                    Live FX Nominal Parity
                  </span>
                  <span className="font-mono text-[11px] text-[#94A3B8] tabular-nums">
                    1 {selectedForeignCurrency} = ₹{selectedFxRate}
                  </span>
                </div>

                <div className="flex items-baseline justify-between gap-2 pt-1">
                  <span className="font-mono text-xs text-[#E3E1E9]">{selectedForeignCurrency} Nominal</span>
                  <span className="font-mono text-xl font-bold text-[#FFB95F] tabular-nums">
                    {formatSovereignCurrency(convertedForeignValue, selectedForeignCurrency)}
                  </span>
                </div>

                <div className="flex flex-wrap gap-1 pt-1">
                  {SOVEREIGN_CURRENCIES.map((curr) => (
                    <button
                      key={curr}
                      type="button"
                      onClick={() => setSelectedForeignCurrency(curr)}
                      className={`px-2 py-0.5 rounded font-mono text-[10px] transition-colors cursor-pointer ${
                        selectedForeignCurrency === curr
                          ? 'bg-[#F59E0B] text-[#090A0F] font-bold'
                          : 'bg-[#090A0F]/70 text-[#94A3B8] hover:text-white'
                      }`}
                    >
                      {curr}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* 4-SOURCE REAL-LIFE CONSUS AVERAGE BREAKDOWN */}
            <div className="rounded-xl bg-[#090A0F]/90 border border-white/10 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="font-mono text-xs font-semibold text-[#F8FAFC] flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-[#4EDEA3]" />
                  <span>How Your Relatable Average Outcome ({formatInrCompact(finalInr)}) Is Derived</span>
                </div>
                <span className="font-mono text-[11px] text-[#94A3B8]">4-Source Real-Data Consensus</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                <div className="p-2.5 rounded-lg bg-white/[0.02] border border-white/5">
                  <div className="text-[10px] text-[#94A3B8]">1. Naukri / AmbitionBox Median</div>
                  <div className="text-sm font-bold text-[#E3E1E9] mt-1 tabular-nums">
                    {formatInrCompact(avgBreakdown?.massMarketMedianInr ?? finalInr * 0.72)}
                  </div>
                  <div className="text-[10px] text-[#64748B]">All-India Mass Market</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white/[0.02] border border-white/5">
                  <div className="text-[10px] text-[#94A3B8]">2. Glassdoor / GCC Cohort</div>
                  <div className="text-sm font-bold text-[#4CD7F6] mt-1 tabular-nums">
                    {formatInrCompact(avgBreakdown?.gccProductBenchmarkInr ?? finalInr * 0.96)}
                  </div>
                  <div className="text-[10px] text-[#64748B]">{profile.indianCity} Mid-Product</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white/[0.02] border border-white/5">
                  <div className="text-[10px] text-[#94A3B8]">3. 4-Model Python ML Mean</div>
                  <div className="text-sm font-bold text-[#FFB95F] mt-1 tabular-nums">
                    {formatInrCompact(avgBreakdown?.mlEnsembleMeanInr ?? finalInr * 1.03)}
                  </div>
                  <div className="text-[10px] text-[#64748B]">Ridge + GBDT + RF</div>
                </div>

                <div className="p-2.5 rounded-lg bg-[#10B981]/10 border border-[#10B981]/30">
                  <div className="text-[10px] text-[#4EDEA3]">4. Final Average Outcome</div>
                  <div className="text-sm font-bold text-[#4EDEA3] mt-1 tabular-nums">
                    {formatInrCompact(finalInr)}
                  </div>
                  <div className="text-[10px] text-[#94A3B8]">Weighted Consensus</div>
                </div>
              </div>
            </div>

            {/* INDIA CTC BREAKDOWN: FIXED BASE vs BONUS vs ESOP vs MONTHLY IN-HAND */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
              <div className="rounded-xl bg-[#090A0F] border border-white/10 p-3.5">
                <div className="flex items-center justify-between text-[11px] text-[#94A3B8] font-mono">
                  <span>Fixed Base Pay</span>
                  <span className="text-[#4EDEA3]">{reg?.componentSplit.basePct ?? 78}%</span>
                </div>
                <div className="font-mono text-lg font-semibold text-[#F8FAFC] mt-1 tabular-nums">
                  {formatInrCompact(baseInr)}
                </div>
                <div className="font-mono text-[11px] text-[#64748B] mt-0.5 tabular-nums">
                  {formatInrExact(baseInr)}
                </div>
              </div>

              <div className="rounded-xl bg-[#090A0F] border border-white/10 p-3.5">
                <div className="flex items-center justify-between text-[11px] text-[#94A3B8] font-mono">
                  <span>Variable Bonus</span>
                  <span className="text-[#4CD7F6]">{reg?.componentSplit.bonusPct ?? 12}%</span>
                </div>
                <div className="font-mono text-lg font-semibold text-[#F8FAFC] mt-1 tabular-nums">
                  {formatInrCompact(bonusInr)}
                </div>
                <div className="font-mono text-[11px] text-[#64748B] mt-0.5 tabular-nums">
                  {formatInrExact(bonusInr)}
                </div>
              </div>

              <div className="rounded-xl bg-[#090A0F] border border-white/10 p-3.5">
                <div className="flex items-center justify-between text-[11px] text-[#94A3B8] font-mono">
                  <span>Annual ESOP / RSU</span>
                  <span className="text-[#FFB95F]">{reg?.componentSplit.equityPct ?? 10}%</span>
                </div>
                <div className="font-mono text-lg font-semibold text-[#F8FAFC] mt-1 tabular-nums">
                  {formatInrCompact(equityInr)}
                </div>
                <div className="font-mono text-[11px] text-[#64748B] mt-0.5 tabular-nums">
                  {formatInrExact(equityInr)}
                </div>
              </div>

              <div className="rounded-xl bg-[#090A0F] border border-[#10B981]/35 p-3.5">
                <div className="flex items-center justify-between text-[11px] text-[#4EDEA3] font-mono">
                  <span>Monthly In-Hand</span>
                  <span>Tax: {taxInfo?.effectiveTaxRatePct ?? 8.5}%</span>
                </div>
                <div className="font-mono text-lg font-bold text-[#4EDEA3] mt-1 tabular-nums">
                  {formatInrExact(monthlyInHandInr)}
                </div>
                <div className="font-mono text-[11px] text-[#64748B] mt-0.5 tabular-nums">
                  FY26-27 Tax: {formatInrCompact(taxInfo?.annualIncomeTaxInr ?? 0)}/yr
                </div>
              </div>
            </div>
          </div>

          {/* MULTI-MODEL MACHINE LEARNING ENSEMBLE COMPARISON MATRIX */}
          <div className="obsidian-panel rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
              <div>
                <h3 className="text-base font-semibold text-[#F8FAFC] flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#4CD7F6]" />
                  <span>Python Multi-Model Machine Learning Ensemble Telemetry</span>
                </h3>
                <p className="text-xs text-[#94A3B8]">
                  Trained on PPP-calibrated real-life Indian salary records · Click any model to switch
                </p>
              </div>
              <span className="font-mono text-xs text-[#4EDEA3]">4 Active ML Estimators</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {(
                reg?.mlEnsembleComparison ?? [
                  {
                    modelName: 'Stacked Meta-Ensemble',
                    predictedInr: finalInr,
                    r2Score: 0.9645,
                    rmseLog: 0.1312,
                    architecture: 'Relatable Consensus (ML + AmbitionBox/Naukri Median)',
                  },
                  {
                    modelName: 'Gradient Boosting (GBDT)',
                    predictedInr: Math.round(finalInr * 0.97),
                    r2Score: 0.958,
                    rmseLog: 0.142,
                    architecture: '28 Sequential Residual Regression Trees',
                  },
                  {
                    modelName: 'Random Forest Regressor',
                    predictedInr: Math.round(finalInr * 1.04),
                    r2Score: 0.912,
                    rmseLog: 0.184,
                    architecture: '18 Bootstrap Aggregated CART Trees',
                  },
                  {
                    modelName: 'L2 Ridge Regression',
                    predictedInr: Math.round(finalInr * 1.01),
                    r2Score: 0.941,
                    rmseLog: 0.158,
                    architecture: 'PPP-Normalized Normal Equations (L2 λ=0.15)',
                  },
                ]
              ).map((m) => {
                const isSelected = profile.mlModel === m.modelName;
                return (
                  <button
                    key={m.modelName}
                    type="button"
                    onClick={() =>
                      onUpdateProfile((prev) => ({
                        ...prev,
                        mlModel: m.modelName as MLModelType,
                      }))
                    }
                    className={`rounded-xl p-3.5 text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#06B6D4]/15 border border-[#06B6D4] text-[#F8FAFC]'
                        : 'bg-[#090A0F] border border-white/10 text-[#94A3B8] hover:border-white/25'
                    }`}
                  >
                    <div className="font-mono text-xs font-semibold text-[#F8FAFC] truncate">
                      {m.modelName}
                    </div>
                    <div className="font-mono text-lg font-bold text-[#4EDEA3] mt-1 tabular-nums">
                      {formatInrCompact(m.predictedInr)}
                    </div>
                    <div className="font-mono text-[11px] text-[#4CD7F6] mt-1 tabular-nums">
                      R² = {m.r2Score} · RMSE = {m.rmseLog}
                    </div>
                    <div className="text-[10px] text-[#64748B] mt-1 line-clamp-1">
                      {m.architecture}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* LLM-DRIVEN VALIDATION & OUTLIER INTERCEPTOR DIAGNOSTIC BANNER */}
          <div
            className={`rounded-2xl p-6 space-y-4 ${
              val?.isIntercepted
                ? 'crimson-diagnostic'
                : 'obsidian-panel border-[#10B981]/30'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                {val?.isIntercepted ? (
                  <AlertTriangle className="w-5 h-5 text-[#F43F5E] shrink-0" />
                ) : (
                  <ShieldCheck className="w-5 h-5 text-[#10B981] shrink-0" />
                )}
                <div>
                  <h3 className="text-base font-semibold text-[#F8FAFC]">
                    LLM Actuarial Validation &amp; Sanity Interceptor
                  </h3>
                  <p className="font-mono text-xs text-[#94A3B8]">
                    {val?.validationCode || '[VERIFIED_INDIA_ML_PARITY]'} · Confidence:{' '}
                    {val?.confidenceScore ?? 98}% · {val?.llmSource || 'Gemini 3.8 Flash Audit'}
                  </p>
                </div>
              </div>

              <div className="font-mono text-xs">
                {val?.isIntercepted ? (
                  <span className="text-[#FFB4AB] font-semibold">
                    OUTLIER INTERCEPTED &amp; CLAMPED
                  </span>
                ) : (
                  <span className="text-[#4EDEA3] font-semibold">
                    REAL-LIFE INDIA MARKET VERIFIED
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="rounded-xl bg-[#090A0F]/90 border border-white/10 p-3.5">
                <div className="font-mono text-[11px] text-[#94A3B8]">
                  1. Python Raw ML Output
                </div>
                <div
                  className={`font-mono text-lg font-semibold mt-1 tabular-nums ${
                    val?.isIntercepted ? 'line-through text-[#F43F5E]' : 'text-[#F8FAFC]'
                  }`}
                >
                  {formatInrCompact(rawInr)}
                </div>
              </div>

              <div className="rounded-xl bg-[#090A0F]/90 border border-white/10 p-3.5">
                <div className="font-mono text-[11px] text-[#94A3B8]">
                  2. LLM Sanity Correction Delta
                </div>
                <div
                  className={`font-mono text-lg font-semibold mt-1 tabular-nums ${
                    (val?.correctionDeltaInr ?? 0) === 0
                      ? 'text-[#94A3B8]'
                      : 'text-[#FFB95F]'
                  }`}
                >
                  {(val?.correctionDeltaInr ?? 0) === 0
                    ? '₹0 (No Drift)'
                    : formatInrCompact(val?.correctionDeltaInr ?? 0)}
                </div>
              </div>

              <div className="rounded-xl bg-[#090A0F]/90 border border-[#10B981]/30 p-3.5">
                <div className="font-mono text-[11px] text-[#4EDEA3]">
                  3. Final Validated India CTC
                </div>
                <div className="font-mono text-lg font-bold text-[#4EDEA3] mt-1 tabular-nums">
                  {formatInrCompact(finalInr)}
                </div>
              </div>
            </div>

            <p className="text-sm leading-relaxed text-[#E3E1E9]">
              {val?.validationReasoning ||
                'Machine Learning prediction verified against relatable Indian metro & company-tier compensation benchmarks.'}
            </p>
          </div>

          {/* REAL-TIME GOOGLE SEARCH GROUNDED INDIAN MARKET PULSE */}
          <div className="obsidian-panel rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <Globe className="w-4 h-4 text-[#4CD7F6]" />
                <div>
                  <h3 className="text-sm font-semibold text-[#F8FAFC]">
                    Real-Time Google Search Grounded India Market Pulse ({profile.indianCity})
                  </h3>
                  <p className="text-xs text-[#94A3B8]">
                    Live 2026 Indian salary benchmarks grounded via Gemini Google Search tool
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onFetchLivePulse}
                disabled={isLoadingPulse}
                className="px-3.5 py-1.5 rounded-lg bg-[#06B6D4]/15 border border-[#06B6D4] hover:bg-[#06B6D4] hover:text-[#090A0F] font-mono text-xs font-semibold text-[#4CD7F6] flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingPulse ? 'animate-spin' : ''}`} />
                <span>{isLoadingPulse ? 'Searching India Web...' : 'Fetch Live Search Benchmark'}</span>
              </button>
            </div>

            {marketPulse ? (
              <div className="space-y-3 text-xs">
                <p className="text-[#E3E1E9] leading-relaxed whitespace-pre-line">
                  {marketPulse.summary}
                </p>
                {marketPulse.sources && marketPulse.sources.length > 0 && (
                  <div className="pt-2 border-t border-white/5 flex flex-wrap items-center gap-3">
                    <span className="font-mono text-[11px] text-[#94A3B8]">Grounded Web Citations:</span>
                    {marketPulse.sources.map((src, i) => (
                      <a
                        key={i}
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-mono text-[11px] text-[#4CD7F6] hover:text-[#4EDEA3] flex items-center gap-1 underline underline-offset-4"
                      >
                        <span>{src.title}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-xs text-[#94A3B8] font-mono">
                Click &quot;Fetch Live Search Benchmark&quot; to query real-time 2026 Indian compensation web
                sources for {reg?.effectiveRole || profile.role} in {profile.indianCity}.
              </div>
            )}
          </div>

          {/* PERCENTILE BANDS & PYTHON FEATURE ATTRIBUTION */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="obsidian-panel rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-[#F8FAFC]">
                  {profile.indianCity} Cohort Percentiles (INR)
                </h3>
                <span className="font-mono text-xs text-[#4CD7F6]">P10 — P90 Spread</span>
              </div>

              <div className="space-y-3">
                {[
                  { label: 'P10 (Entry / Service Base)', val: reg?.percentileBandsInr.p10 ?? finalInr * 0.72, pct: 40 },
                  { label: 'P25 (Conservative Offer)', val: reg?.percentileBandsInr.p25 ?? finalInr * 0.85, pct: 55 },
                  { label: 'P50 (Average Estimated Outcome)', val: finalInr, pct: 72, highlight: true },
                  { label: 'P75 (Strong Product / GCC Offer)', val: reg?.percentileBandsInr.p75 ?? finalInr * 1.18, pct: 86 },
                  { label: 'P90 (Top Competing Offer)', val: reg?.percentileBandsInr.p90 ?? finalInr * 1.38, pct: 100 },
                ].map((band) => (
                  <div key={band.label} className="space-y-1">
                    <div className="flex justify-between font-mono text-xs tabular-nums">
                      <span className={band.highlight ? 'text-[#4EDEA3] font-semibold' : 'text-[#94A3B8]'}>
                        {band.label}
                      </span>
                      <span className={band.highlight ? 'text-[#4EDEA3] font-bold' : 'text-[#F8FAFC]'}>
                        {formatInrCompact(band.val)}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-[#090A0F] overflow-hidden border border-white/5">
                      <div
                        className={`h-full rounded-full ${
                          band.highlight
                            ? 'bg-gradient-to-r from-[#06B6D4] to-[#10B981]'
                            : 'bg-white/20'
                        }`}
                        style={{ width: `${band.pct}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="obsidian-panel rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-[#F8FAFC]">
                  ML Feature Attribution (INR)
                </h3>
                <span className="font-mono text-xs text-[#4EDEA3]">SHAP / Elasticity Delta</span>
              </div>

              <div className="space-y-2.5 font-mono text-xs">
                {[
                  {
                    name: 'Role Base Anchor (India)',
                    amount: reg?.featureAttributionInr.roleBaseAnchor ?? 1100000,
                    note: reg?.effectiveRole || profile.role,
                  },
                  {
                    name: 'Experience Curve Premium',
                    amount: reg?.featureAttributionInr.experiencePremium ?? 0,
                    note: isStudent ? 'Locked (0 yrs Student)' : `${profile.experienceYears} yrs non-linear`,
                  },
                  {
                    name: 'Verified Skills Arbitrage',
                    amount: reg?.featureAttributionInr.skillsArbitrage ?? 280000,
                    note: `${profile.skills.length} active skills`,
                  },
                  {
                    name: 'Academic Credential Delta',
                    amount: reg?.featureAttributionInr.educationCredentialDelta ?? 120000,
                    note: profile.educationLevel,
                  },
                  {
                    name: 'Indian Hub Differential',
                    amount: reg?.featureAttributionInr.locationMarketAdjustment ?? 0,
                    note: `${profile.indianCity} (${profile.locationTier})`,
                  },
                ].map((item) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between py-2 border-b border-white/5 last:border-none"
                  >
                    <div>
                      <div className="text-[#E3E1E9]">{item.name}</div>
                      <div className="text-[11px] text-[#64748B]">{item.note}</div>
                    </div>
                    <div
                      className={`font-semibold tabular-nums ${
                        item.amount > 0
                          ? 'text-[#4EDEA3]'
                          : item.amount < 0
                            ? 'text-[#FFB4AB]'
                            : 'text-[#94A3B8]'
                      }`}
                    >
                      {item.amount >= 0 ? '+' : ''}
                      {formatInrCompact(item.amount)}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-xs text-[#94A3B8]">
                  View 3-Horizon Indian Career Roadmap
                </span>
                <button
                  type="button"
                  onClick={() => onNavigateTab('blueprint')}
                  className="font-mono text-xs font-semibold text-[#4CD7F6] hover:text-[#4EDEA3] flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Open Career Blueprint</span>
                  <TrendingUp className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
