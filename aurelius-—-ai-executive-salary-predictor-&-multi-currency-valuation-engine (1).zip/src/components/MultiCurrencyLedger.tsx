import React, { useState } from 'react';
import { Database, Filter, Lock, Plus, Search } from 'lucide-react';
import {
  DatasetRecord,
  EmploymentStatus,
  formatInrCompact,
  formatInrExact,
  formatSovereignCurrency,
  IndianCity,
  ROLE_CATALOG_BY_CATEGORY,
  RoleCategory,
} from '../types/compensation';

interface MultiCurrencyLedgerProps {
  records: DatasetRecord[];
  fxRates: Record<string, number>;
  modelMetrics: {
    r2Score: number;
    rmseLog: number;
    totalRecords: number;
  };
  onAddRecord: (newRecordPayload: Record<string, unknown>) => Promise<void>;
  isAdding: boolean;
}

const INDIAN_CITIES: IndianCity[] = [
  'Bengaluru',
  'Hyderabad',
  'Mumbai',
  'Delhi NCR (Gurugram/Noida)',
  'Pune',
  'Chennai',
  'Ahmedabad / GIFT City / Kochi',
  'Remote India (Global Entity)',
];

export const MultiCurrencyLedger: React.FC<MultiCurrencyLedgerProps> = ({
  records,
  fxRates,
  modelMetrics,
  onAddRecord,
  isAdding,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState<string>('ALL');
  const [showAddForm, setShowAddForm] = useState(false);

  const [newRole, setNewRole] = useState('Machine Learning Engineer');
  const [newCategory, setNewCategory] = useState<RoleCategory>('AI & Data Science');
  const [newStatus, setNewStatus] = useState<EmploymentStatus>('Full-Time Professional');
  const [newExp, setNewExp] = useState<number>(5);
  const [newIndianCity, setNewIndianCity] = useState<IndianCity>('Bengaluru');
  const [newCurrency, setNewCurrency] = useState<string>('INR');
  const [newRawSalary, setNewRawSalary] = useState<number>(4500000);
  const [newLocation, setNewLocation] = useState<string>('Tier 1 India Metro');
  const [newSkills, setNewSkills] = useState<string>('Python, PyTorch, Kubernetes');

  const isNewStudent = newStatus === 'Student';

  const currencies = ['ALL', ...Object.keys(fxRates)];

  const filteredRecords = records.filter((rec) => {
    const matchesCurrency = selectedCurrency === 'ALL' || rec.currency === selectedCurrency;
    const q = searchQuery.trim().toLowerCase();
    const matchesQuery =
      !q ||
      rec.role.toLowerCase().includes(q) ||
      rec.category.toLowerCase().includes(q) ||
      rec.record_id.toLowerCase().includes(q) ||
      (rec.indian_city || '').toLowerCase().includes(q) ||
      rec.employment_status.toLowerCase().includes(q) ||
      rec.primary_skills.some((s) => s.toLowerCase().includes(q));
    return matchesCurrency && matchesQuery;
  });

  const handleSubmitNewRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    const skillsArray = newSkills
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    await onAddRecord({
      role: newRole,
      category: newCategory,
      employment_status: newStatus,
      experience_years: isNewStudent ? 0 : newExp,
      education_level: "Master's (M.Tech / MS / MBA)",
      location_tier: newLocation,
      indian_city: newIndianCity,
      currency: newCurrency,
      raw_annual_salary: newRawSalary,
      equity_pct: isNewStudent ? 5 : 18,
      bonus_pct: isNewStudent ? 8 : 15,
      primary_skills: skillsArray.length ? skillsArray : ['Python', 'SQL'],
      company_tier: 'Indian Tech Unicorn / Decacorn',
    });
    setShowAddForm(false);
  };

  const previewFx = fxRates[newCurrency] || 1;
  const previewConvertedInr = newRawSalary * previewFx;

  return (
    <div className="space-y-6">
      <section className="obsidian-panel rounded-2xl p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <div className="font-mono text-xs text-[#4EDEA3] uppercase tracking-wider">
              Real-Time Live FX Multi-Currency Ingestion &amp; India INR Ledger
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#F8FAFC] mt-0.5">
              Normalized Indian &amp; Global Compensation Dataset ({records.length} Records)
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="font-mono text-xs text-[#94A3B8] tabular-nums">
              ML Ensemble Fit: <span className="text-[#4EDEA3] font-semibold">R² = {modelMetrics.r2Score}</span> · RMSE = {modelMetrics.rmseLog}
            </div>
            <button
              type="button"
              onClick={() => setShowAddForm((prev) => !prev)}
              className="px-4 py-2 rounded-lg bg-[#10B981] hover:bg-[#34D399] text-[#090A0F] font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{showAddForm ? 'Close Ingestion Form' : 'Ingest Multi-Currency Record'}</span>
            </button>
          </div>
        </div>

        {/* Live FX Exchange Matrix to INR */}
        <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
          {Object.entries(fxRates).map(([curr, rate]) => (
            <div
              key={curr}
              className="rounded-lg bg-[#090A0F] border border-white/10 px-3 py-2 font-mono text-xs tabular-nums"
            >
              <div className="text-[#94A3B8] text-[10px]">1 {curr} → INR</div>
              <div className="text-[#FFB95F] font-semibold mt-0.5">₹{rate}</div>
            </div>
          ))}
        </div>

        {showAddForm && (
          <form
            onSubmit={handleSubmitNewRecord}
            className="rounded-xl bg-[#090A0F] border border-[#10B981]/40 p-5 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="font-mono text-xs font-semibold text-[#4EDEA3]">
                Append New Record to backend/multi_currency_salaries.csv &amp; Re-Fit ML Ensemble
              </span>
              <span className="font-mono text-xs text-[#FFB95F] tabular-nums">
                Live INR Conversion Preview: {formatInrCompact(previewConvertedInr)} ({formatInrExact(previewConvertedInr)})
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1">Role Title</label>
                <input
                  type="text"
                  required
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value)}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                />
              </div>

              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1">Domain Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as RoleCategory)}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                >
                  {Object.keys(ROLE_CATALOG_BY_CATEGORY).map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1">
                  Employment Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => {
                    const st = e.target.value as EmploymentStatus;
                    setNewStatus(st);
                    if (st === 'Student') setNewExp(0);
                  }}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                >
                  <option value="Full-Time Professional">Full-Time Professional</option>
                  <option value="Executive / Director">Executive / Director</option>
                  <option value="Student">Student (Experience Locked at 0)</option>
                  <option value="Freelance / Consultant">Freelance / Consultant</option>
                  <option value="Career Transition">Career Transition</option>
                </select>
              </div>

              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1 flex items-center gap-1">
                  <span>Experience (Years)</span>
                  {isNewStudent && <Lock className="w-3 h-3 text-[#4CD7F6]" />}
                </label>
                <input
                  type="number"
                  min={0}
                  max={30}
                  disabled={isNewStudent}
                  value={isNewStudent ? 0 : newExp}
                  onChange={(e) => setNewExp(Number(e.target.value) || 0)}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed tabular-nums"
                />
              </div>

              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1">Indian Tech Hub</label>
                <select
                  value={newIndianCity}
                  onChange={(e) => setNewIndianCity(e.target.value as IndianCity)}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#4EDEA3]"
                >
                  {INDIAN_CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1">Source Currency</label>
                <select
                  value={newCurrency}
                  onChange={(e) => setNewCurrency(e.target.value)}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#FFB95F]"
                >
                  {Object.keys(fxRates).map((c) => (
                    <option key={c} value={c}>
                      {c} (1 {c} = ₹{fxRates[c]})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1">
                  Raw Annual Salary ({newCurrency})
                </label>
                <input
                  type="number"
                  min={1000}
                  required
                  value={newRawSalary}
                  onChange={(e) => setNewRawSalary(Number(e.target.value) || 0)}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC] tabular-nums"
                />
              </div>

              <div>
                <label className="block font-mono text-xs text-[#94A3B8] mb-1">
                  Skills (Comma-separated)
                </label>
                <input
                  type="text"
                  value={newSkills}
                  onChange={(e) => setNewSkills(e.target.value)}
                  className="w-full rounded-lg bg-[#0D0F17] border border-white/15 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                />
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isAdding}
                className="px-5 py-2.5 rounded-lg bg-[#10B981] text-[#090A0F] font-mono text-xs font-bold uppercase tracking-wider hover:bg-[#34D399] transition-colors cursor-pointer"
              >
                {isAdding ? 'Ingesting & Re-Fitting Python ML Models...' : 'Commit Record & Re-Train ML Ensemble'}
              </button>
            </div>
          </form>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-[#64748B] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter ledger by Indian city, role, skill, or ID..."
              className="w-full rounded-lg bg-[#090A0F] border border-white/15 pl-9 pr-3 py-2 text-xs font-mono text-[#F8FAFC] placeholder:text-[#64748B] focus:border-[#06B6D4] focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <Filter className="w-3.5 h-3.5 text-[#64748B] mr-1" />
            {currencies.map((curr) => (
              <button
                key={curr}
                type="button"
                onClick={() => setSelectedCurrency(curr)}
                className={`px-2.5 py-1 rounded text-xs font-mono transition-colors cursor-pointer ${
                  selectedCurrency === curr
                    ? 'bg-[#06B6D4] text-[#090A0F] font-bold'
                    : 'bg-[#090A0F] border border-white/10 text-[#94A3B8] hover:text-white'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="obsidian-panel rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 bg-[#090A0F]/60 font-mono text-[11px] text-[#94A3B8] uppercase">
                <th className="py-3.5 px-4">ID</th>
                <th className="py-3.5 px-4">Role &amp; Domain</th>
                <th className="py-3.5 px-4">Indian Hub &amp; Tier</th>
                <th className="py-3.5 px-4">Status &amp; Tenure</th>
                <th className="py-3.5 px-4 text-right">Raw Salary</th>
                <th className="py-3.5 px-4 text-right">Live FX</th>
                <th className="py-3.5 px-4 text-right">Normalized INR (₹)</th>
                <th className="py-3.5 px-4">Primary Skills</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs">
              {filteredRecords.map((rec) => (
                <tr key={rec.record_id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="py-3 px-4 font-mono text-[#64748B] whitespace-nowrap">
                    {rec.record_id}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-[#F8FAFC]">{rec.role}</div>
                    <div className="text-[11px] text-[#64748B]">{rec.category}</div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="text-[#4EDEA3] font-medium">{rec.indian_city || 'Bengaluru'}</div>
                    <div className="text-[11px] text-[#64748B]">{rec.company_tier}</div>
                  </td>
                  <td className="py-3 px-4 font-mono whitespace-nowrap tabular-nums">
                    <div className={rec.employment_status === 'Student' ? 'text-[#4CD7F6]' : 'text-[#E3E1E9]'}>
                      {rec.employment_status}
                    </div>
                    <div className="text-[11px] text-[#64748B]">
                      {rec.experience_years} yrs · {rec.education_level}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-[#FFB95F] whitespace-nowrap tabular-nums">
                    {rec.currency} {formatSovereignCurrency(rec.raw_annual_salary, rec.currency)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-[#64748B] whitespace-nowrap tabular-nums">
                    ×{rec.fx_rate_to_inr}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-semibold text-[#4EDEA3] whitespace-nowrap tabular-nums">
                    <div>{formatInrCompact(rec.converted_inr)}</div>
                    <div className="text-[10px] text-[#64748B] font-normal">
                      {formatInrExact(rec.converted_inr)}
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#94A3B8]">
                    {rec.primary_skills.join(' · ')}
                  </td>
                </tr>
              ))}

              {filteredRecords.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#94A3B8] font-mono text-xs">
                    <Database className="w-6 h-6 text-[#64748B] mx-auto mb-2" />
                    No multi-currency records match your current filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
