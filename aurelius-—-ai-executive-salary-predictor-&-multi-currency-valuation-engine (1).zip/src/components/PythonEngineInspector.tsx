import React, { useEffect, useState } from 'react';
import { Check, Code2, Copy, FileCode, Terminal } from 'lucide-react';

export const PythonEngineInspector: React.FC = () => {
  const [sources, setSources] = useState<{
    salaryEnginePy: string;
    appPy: string;
    requirementsTxt: string;
  } | null>(null);
  const [activeFile, setActiveFile] = useState<'salaryEnginePy' | 'appPy' | 'requirementsTxt'>('salaryEnginePy');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/backend-source')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.salaryEnginePy) {
          setSources(data);
        }
      })
      .catch(() => {
        // Ignore error
      });
  }, []);

  const currentCode = sources ? sources[activeFile] : '# Loading live Python source...';

  const handleCopy = () => {
    if (!currentCode) return;
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <section className="obsidian-panel rounded-2xl p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <div className="font-mono text-xs text-[#4CD7F6] uppercase tracking-wider">
              Production Python Backend Architecture &amp; Deployment Reference
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#F8FAFC] mt-0.5">
              Modular Python Regression &amp; LLM Validation Source
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {[
              { id: 'salaryEnginePy', label: 'backend/salary_engine.py' },
              { id: 'appPy', label: 'backend/app.py' },
              { id: 'requirementsTxt', label: 'requirements.txt' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveFile(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg font-mono text-xs transition-colors whitespace-nowrap ${
                  activeFile === tab.id
                    ? 'bg-[#10B981] text-[#090A0F] font-bold'
                    : 'bg-[#090A0F] border border-white/10 text-[#94A3B8] hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Architectural Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="rounded-xl bg-[#090A0F] border border-white/10 p-4 space-y-1">
            <div className="font-mono text-[#4EDEA3] font-semibold">
              01. Multi-Currency to INR Normalization
            </div>
            <p className="text-[#94A3B8] leading-relaxed">
              Ingests local CSV datasets across 10 sovereign currencies (USD, EUR, GBP, SGD, AED, CHF,
              CAD, AUD, JPY, INR) and normalizes values into Indian Rupees prior to matrix fitting.
            </p>
          </div>

          <div className="rounded-xl bg-[#090A0F] border border-white/10 p-4 space-y-1">
            <div className="font-mono text-[#4CD7F6] font-semibold">
              02. L2 Ridge Regression &amp; Student Lock
            </div>
            <p className="text-[#94A3B8] leading-relaxed">
              Solves normal equations β = (XᵀX + λI)⁻¹Xᵀy in pure Python 3.10. Enforces hard domain
              guardrails clamping experience to 0.0 years when status is set to Student.
            </p>
          </div>

          <div className="rounded-xl bg-[#090A0F] border border-white/10 p-4 space-y-1">
            <div className="font-mono text-[#FFB95F] font-semibold">
              03. Gemini LLM Sanity Interceptor
            </div>
            <p className="text-[#94A3B8] leading-relaxed">
              Validates raw regression outputs against sovereign compensation bands, intercepting and
              clamping unrealistic outliers while synthesizing 3-horizon career roadmaps.
            </p>
          </div>
        </div>
      </section>

      {/* LIVE SOURCE VIEWER */}
      <section className="obsidian-panel rounded-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 bg-[#090A0F] border-b border-white/10">
          <div className="flex items-center gap-2 font-mono text-xs text-[#E3E1E9]">
            <FileCode className="w-4 h-4 text-[#4CD7F6]" />
            <span>
              {activeFile === 'salaryEnginePy'
                ? 'backend/salary_engine.py'
                : activeFile === 'appPy'
                  ? 'backend/app.py'
                  : 'requirements.txt'}
            </span>
          </div>

          <button
            type="button"
            onClick={handleCopy}
            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 font-mono text-xs text-[#F8FAFC] flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#4EDEA3]" />
                <span className="text-[#4EDEA3]">Copied Source</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#94A3B8]" />
                <span>Copy Module</span>
              </>
            )}
          </button>
        </div>

        <pre className="p-5 text-xs font-mono text-[#E3E1E9] overflow-x-auto max-h-[540px] leading-relaxed bg-[#090A0F]/80">
          <code>{currentCode}</code>
        </pre>
      </section>
    </div>
  );
};
