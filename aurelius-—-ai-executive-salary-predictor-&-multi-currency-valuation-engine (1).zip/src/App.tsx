import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Download } from 'lucide-react';
import {
  CandidateProfile,
  DatasetRecord,
  formatInrCompact,
  formatInrExact,
  LiveMarketPulseResponse,
  PredictionResponse,
} from './types/compensation';
import { ValuationDesk } from './components/ValuationDesk';
import { CareerBlueprint } from './components/CareerBlueprint';
import { MultiCurrencyLedger } from './components/MultiCurrencyLedger';
import { PythonEngineInspector } from './components/PythonEngineInspector';

const INITIAL_PROFILE: CandidateProfile = {
  employmentStatus: 'Full-Time Professional',
  role: 'Machine Learning Engineer',
  customRoleTitle: 'AI & Data Automation Specialist',
  category: 'AI & Data Science',
  customComplexity: 1.05,
  experienceYears: 3,
  educationLevel: "Bachelor's (B.Tech / B.Sc)",
  locationTier: 'Tier 1 India Metro',
  indianCity: 'Bengaluru',
  companyTier: 'Global Capability Center (GCC India)',
  mlModel: 'Stacked Meta-Ensemble',
  skills: ['Python', 'PyTorch', 'SQL', 'AWS'],
  stressTestAnomaly: false,
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'desk' | 'blueprint' | 'ledger' | 'engine'>('desk');
  const [profile, setProfile] = useState<CandidateProfile>(INITIAL_PROFILE);
  const [prediction, setPrediction] = useState<PredictionResponse | null>(null);
  const [isLoadingPrediction, setIsLoadingPrediction] = useState<boolean>(false);

  const [marketPulse, setMarketPulse] = useState<LiveMarketPulseResponse | null>(null);
  const [isLoadingPulse, setIsLoadingPulse] = useState<boolean>(false);

  const [datasetRecords, setDatasetRecords] = useState<DatasetRecord[]>([]);
  const [fxRates, setFxRates] = useState<Record<string, number>>({
    INR: 1.0,
    USD: 86.45,
    EUR: 93.2,
    GBP: 110.85,
    SGD: 64.5,
    AED: 23.54,
    CHF: 98.1,
    CAD: 61.8,
    AUD: 56.15,
    JPY: 0.58,
  });
  const [datasetMetrics, setDatasetMetrics] = useState({
    r2Score: 0.9645,
    rmseLog: 0.1312,
    totalRecords: 32,
  });
  const [isAddingRecord, setIsAddingRecord] = useState(false);

  const isFirstMount = useRef(true);

  const fetchDataset = useCallback(async () => {
    try {
      const res = await fetch('/api/dataset');
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.records)) {
        setDatasetRecords(data.records);
      }
      if (data.fxRatesToInr) {
        setFxRates(data.fxRatesToInr);
      }
      if (data.modelMetrics) {
        setDatasetMetrics(data.modelMetrics);
      }
    } catch {
      // Keep default state on network error
    }
  }, []);

  const runPrediction = useCallback(
    async (overrideProfile?: CandidateProfile) => {
      const targetProfile = overrideProfile || profile;
      setIsLoadingPrediction(true);
      try {
        const res = await fetch('/api/predict', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(targetProfile),
        });
        if (res.ok) {
          const data: PredictionResponse = await res.json();
          setPrediction(data);
        }
      } catch {
        // Keep last valid prediction
      } finally {
        setIsLoadingPrediction(false);
      }
    },
    [profile]
  );

  const handleResetSession = useCallback(async () => {
    try {
      await fetch('/api/session/reset', { method: 'POST' });
      await runPrediction(profile);
    } catch {
      // Ignore error
    }
  }, [profile, runPrediction]);

  const fetchLiveMarketPulse = useCallback(
    async (overrideProfile?: CandidateProfile) => {
      const targetProfile = overrideProfile || profile;
      setIsLoadingPulse(true);
      try {
        const res = await fetch('/api/live-market-pulse', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            role:
              targetProfile.role === 'Other' && targetProfile.customRoleTitle
                ? targetProfile.customRoleTitle
                : targetProfile.role,
            indianCity: targetProfile.indianCity,
            experienceYears: targetProfile.experienceYears,
            companyTier: targetProfile.companyTier,
            employmentStatus: targetProfile.employmentStatus,
          }),
        });
        if (res.ok) {
          const data: LiveMarketPulseResponse = await res.json();
          setMarketPulse(data);
        }
      } catch {
        // Ignore error
      } finally {
        setIsLoadingPulse(false);
      }
    },
    [profile]
  );

  useEffect(() => {
    fetchDataset();
    runPrediction(INITIAL_PROFILE);
    fetchLiveMarketPulse(INITIAL_PROFILE);
  }, []);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    const timer = setTimeout(() => {
      runPrediction(profile);
    }, 280);
    return () => clearTimeout(timer);
  }, [profile]);

  const handleAcquireSkillsAndRecalculate = (newSkills: string[]) => {
    const merged = Array.from(new Set([...profile.skills, ...newSkills]));
    const updatedProfile: CandidateProfile = {
      ...profile,
      skills: merged,
    };
    setProfile(updatedProfile);
  };

  const handleAddDatasetRecord = async (newRecordPayload: Record<string, unknown>) => {
    setIsAddingRecord(true);
    try {
      const res = await fetch('/api/dataset/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRecordPayload),
      });
      if (res.ok) {
        await fetchDataset();
        await runPrediction();
      }
    } finally {
      setIsAddingRecord(false);
    }
  };

  const applyPresetScenario = (scenario: 'fresher_it' | 'mid_gcc' | 'other' | 'outlier') => {
    let nextProfile: CandidateProfile;
    if (scenario === 'fresher_it') {
      nextProfile = {
        ...profile,
        employmentStatus: 'Student',
        role: 'Full-Stack Engineer',
        category: 'Core Software & Cloud',
        experienceYears: 0,
        educationLevel: "Bachelor's (B.Tech / B.Sc)",
        locationTier: 'Tier 2 Emerging Tech Hub',
        indianCity: 'Pune',
        companyTier: 'Enterprise IT & Digital Consulting',
        mlModel: 'Stacked Meta-Ensemble',
        skills: ['Java', 'SQL', 'React'],
        stressTestAnomaly: false,
      };
    } else if (scenario === 'other') {
      nextProfile = {
        ...profile,
        employmentStatus: 'Full-Time Professional',
        role: 'Other',
        customRoleTitle: 'GenAI & RAG Application Engineer',
        category: 'AI & Data Science',
        customComplexity: 1.1,
        experienceYears: 4,
        educationLevel: "Master's (M.Tech / MS / MBA)",
        locationTier: 'Tier 1 India Metro',
        indianCity: 'Hyderabad',
        companyTier: 'High-Growth AI / SaaS Startup',
        mlModel: 'Gradient Boosting (GBDT)',
        skills: ['Python', 'PyTorch', 'RAG', 'LLM Fine-Tuning', 'AWS'],
        stressTestAnomaly: false,
      };
    } else if (scenario === 'outlier') {
      nextProfile = {
        ...profile,
        employmentStatus: 'Full-Time Professional',
        role: 'Machine Learning Engineer',
        category: 'AI & Data Science',
        experienceYears: 3,
        educationLevel: "Bachelor's (B.Tech / B.Sc)",
        locationTier: 'Tier 1 India Metro',
        indianCity: 'Delhi NCR (Gurugram/Noida)',
        companyTier: 'Global Capability Center (GCC India)',
        mlModel: 'Stacked Meta-Ensemble',
        skills: ['Python', 'PyTorch', 'SQL', 'AWS'],
        stressTestAnomaly: true,
      };
    } else {
      nextProfile = {
        ...profile,
        employmentStatus: 'Full-Time Professional',
        role: 'Backend Systems Engineer',
        category: 'Core Software & Cloud',
        experienceYears: 3,
        educationLevel: "Bachelor's (B.Tech / B.Sc)",
        locationTier: 'Tier 1 India Metro',
        indianCity: 'Bengaluru',
        companyTier: 'Global Capability Center (GCC India)',
        mlModel: 'Stacked Meta-Ensemble',
        skills: ['Java', 'PostgreSQL', 'AWS', 'Kafka'],
        stressTestAnomaly: false,
      };
    }
    setProfile(nextProfile);
    setActiveTab('desk');
  };

  const handleExportDossier = () => {
    const valInr =
      prediction?.llmValidation.validatedInr ??
      prediction?.regression.calibratedBaselineInr ??
      1812000;
    const report = {
      generatedAt: new Date().toISOString(),
      platform: 'Aureum — Real-Life India ML & Session Average Engine',
      candidateProfile: profile,
      validatedAnnualCtcInr: valInr,
      formattedCtc: `${formatInrCompact(valInr)} (${formatInrExact(valInr)})`,
      realLifeAverageBreakdown: prediction?.regression.realLifeAverageBreakdown,
      sessionOutcomeTelemetry: prediction?.regression.sessionOutcomeTelemetry,
      indianInHandTaxBreakdown: prediction?.regression.indianTaxBreakdown,
      mlEnsembleComparison: prediction?.regression.mlEnsembleComparison,
      regressionOutput: prediction?.regression,
      llmValidationAndCareerInsights: prediction?.llmValidation,
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aureum-india-ml-valuation-${profile.indianCity.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#090A0F] text-[#E3E1E9] flex flex-col">
      {/* STRICT 3-ZONE TOP BAR CONTRACT */}
      <header className="flex items-center justify-between gap-8 px-6 lg:px-12 py-4 border-b border-white/10 bg-[#090A0F]/90 backdrop-blur-md sticky top-0 z-30">
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('desk');
          }}
          className="text-lg font-bold tracking-tight text-[#F8FAFC] whitespace-nowrap shrink-0"
        >
          Aureum
        </a>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#94A3B8]">
          <button
            type="button"
            onClick={() => setActiveTab('desk')}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'desk'
                ? 'text-[#4EDEA3] underline underline-offset-8 decoration-[#10B981]'
                : 'hover:text-[#F8FAFC]'
            }`}
          >
            Valuation Desk
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('blueprint')}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'blueprint'
                ? 'text-[#4EDEA3] underline underline-offset-8 decoration-[#10B981]'
                : 'hover:text-[#F8FAFC]'
            }`}
          >
            Career Blueprint
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ledger')}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'ledger'
                ? 'text-[#4EDEA3] underline underline-offset-8 decoration-[#10B981]'
                : 'hover:text-[#F8FAFC]'
            }`}
          >
            Dataset Ledger
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('engine')}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'engine'
                ? 'text-[#4EDEA3] underline underline-offset-8 decoration-[#10B981]'
                : 'hover:text-[#F8FAFC]'
            }`}
          >
            Python Engine
          </button>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleExportDossier}
            className="px-4 py-2 text-xs font-mono font-semibold uppercase tracking-wider text-[#090A0F] bg-[#10B981] hover:bg-[#34D399] rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Dossier</span>
          </button>
        </div>
      </header>

      {/* MAIN WORKSPACE CONTAINER */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-5 sm:px-8 lg:px-12 py-8 space-y-8">
        {/* EXECUTIVE HERO & SCENARIO CALIBRATION STRIP */}
        <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-white/10 pb-6">
          <div className="space-y-2 max-w-2xl">
            <div className="font-mono text-xs text-[#4EDEA3]">
              Real-Life India Salary Data (AmbitionBox · Naukri · Glassdoor) · 4-Model Python ML · Session Average Outcome
            </div>
            <h1
              className="text-3xl sm:text-4xl font-bold tracking-tight text-[#F8FAFC]"
              style={{ textWrap: 'balance' }}
            >
              Aureum
            </h1>
          </div>

          <div className="space-y-1.5">
            <div className="font-mono text-[11px] text-[#94A3B8]">
              Load Relatable Real-Life India Scenario:
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => applyPresetScenario('fresher_it')}
                className={`px-3 py-1.5 rounded-lg font-mono text-xs transition-colors whitespace-nowrap cursor-pointer ${
                  profile.employmentStatus === 'Student'
                    ? 'bg-[#06B6D4] text-[#090A0F] font-bold'
                    : 'bg-[#0D0F17] border border-white/15 text-[#94A3B8] hover:text-white'
                }`}
              >
                Student / Fresher (Pune IT · ~₹3.5L)
              </button>
              <button
                type="button"
                onClick={() => applyPresetScenario('mid_gcc')}
                className={`px-3 py-1.5 rounded-lg font-mono text-xs transition-colors whitespace-nowrap cursor-pointer ${
                  profile.role === 'Backend Systems Engineer' && !profile.stressTestAnomaly
                    ? 'bg-[#10B981] text-[#090A0F] font-bold'
                    : 'bg-[#0D0F17] border border-white/15 text-[#94A3B8] hover:text-white'
                }`}
              >
                3-Yr Backend SDE (Bengaluru GCC · ~₹13.5L)
              </button>
              <button
                type="button"
                onClick={() => applyPresetScenario('other')}
                className={`px-3 py-1.5 rounded-lg font-mono text-xs transition-colors whitespace-nowrap cursor-pointer ${
                  profile.role === 'Other'
                    ? 'bg-[#F59E0B] text-[#090A0F] font-bold'
                    : 'bg-[#0D0F17] border border-white/15 text-[#94A3B8] hover:text-white'
                }`}
              >
                Custom &apos;Other&apos; Role (Hyderabad Startup)
              </button>
              <button
                type="button"
                onClick={() => applyPresetScenario('outlier')}
                className={`px-3 py-1.5 rounded-lg font-mono text-xs transition-colors whitespace-nowrap cursor-pointer ${
                  profile.stressTestAnomaly
                    ? 'bg-[#F43F5E] text-white font-bold'
                    : 'bg-[#0D0F17] border border-white/15 text-[#94A3B8] hover:text-white'
                }`}
              >
                Outlier Stress-Test (LLM Intercept)
              </button>
            </div>
          </div>
        </section>

        {/* MOBILE NAVIGATION TABS */}
        <div className="flex md:hidden items-center gap-2 overflow-x-auto pb-2">
          {[
            { id: 'desk', label: 'Valuation Desk' },
            { id: 'blueprint', label: 'Career Blueprint' },
            { id: 'ledger', label: 'Dataset Ledger' },
            { id: 'engine', label: 'Python Engine' },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id as any)}
              className={`px-3 py-1.5 rounded-lg font-mono text-xs whitespace-nowrap ${
                activeTab === t.id
                  ? 'bg-[#10B981] text-[#090A0F] font-bold'
                  : 'bg-[#0D0F17] border border-white/10 text-[#94A3B8]'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* ACTIVE WORKSPACE VIEW */}
        {activeTab === 'desk' && (
          <ValuationDesk
            profile={profile}
            onUpdateProfile={(updater) => {
              setProfile((prev) => updater(prev));
            }}
            prediction={prediction}
            isLoading={isLoadingPrediction}
            onRunPrediction={runPrediction}
            onNavigateTab={setActiveTab}
            marketPulse={marketPulse}
            isLoadingPulse={isLoadingPulse}
            onFetchLivePulse={() => fetchLiveMarketPulse(profile)}
            onResetSession={handleResetSession}
          />
        )}

        {activeTab === 'blueprint' && (
          <CareerBlueprint
            profile={profile}
            prediction={prediction}
            onAcquireSkillsAndRecalculate={handleAcquireSkillsAndRecalculate}
          />
        )}

        {activeTab === 'ledger' && (
          <MultiCurrencyLedger
            records={datasetRecords}
            fxRates={fxRates}
            modelMetrics={datasetMetrics}
            onAddRecord={handleAddDatasetRecord}
            isAdding={isAddingRecord}
          />
        )}

        {activeTab === 'engine' && <PythonEngineInspector />}
      </main>

      <footer className="border-t border-white/10 py-6 px-6 lg:px-12 mt-12 text-xs text-[#64748B] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          Aureum · Relatable Real-Life Indian Market ML Ensemble (AmbitionBox · Naukri ·
          Glassdoor · Levels.fyi India) &amp; Session Average Outcome Engine
        </div>
        <div className="flex items-center gap-6">
          <button
            type="button"
            onClick={() => setActiveTab('ledger')}
            className="hover:text-[#E3E1E9] transition-colors cursor-pointer"
          >
            Real-Life India Dataset ({datasetRecords.length} Records)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('engine')}
            className="hover:text-[#E3E1E9] transition-colors cursor-pointer"
          >
            Python 3.10 ML Source
          </button>
        </div>
      </footer>
    </div>
  );
}
