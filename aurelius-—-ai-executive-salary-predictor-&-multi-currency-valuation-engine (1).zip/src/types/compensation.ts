/**
 * ============================================================================
 * AURELIUS // DOMAIN TYPES, INDIA MARKET TAXONOMY & ML ENSEMBLE INTERFACES
 * ============================================================================
 */

export type EmploymentStatus =
  | 'Full-Time Professional'
  | 'Executive / Director'
  | 'Student'
  | 'Freelance / Consultant'
  | 'Career Transition';

export type RoleCategory =
  | 'AI & Data Science'
  | 'Core Software & Cloud'
  | 'Quant & Fintech'
  | 'Cybersecurity & Infrastructure'
  | 'Product & Design'
  | 'Executive Leadership';

export type EducationLevel =
  | 'High School / Bootcamp'
  | "Bachelor's (B.Tech / B.Sc)"
  | "Master's (M.Tech / MS / MBA)"
  | 'Ph.D. / Doctorate';

export type LocationTier =
  | 'Tier 1 India Metro'
  | 'Tier 2 Emerging Tech Hub'
  | 'Remote Sovereign Global'
  | 'Tier 1 Global Hub';

export type IndianCity =
  | 'Bengaluru'
  | 'Hyderabad'
  | 'Mumbai'
  | 'Delhi NCR (Gurugram/Noida)'
  | 'Pune'
  | 'Chennai'
  | 'Ahmedabad / GIFT City / Kochi'
  | 'Remote India (Global Entity)';

export type CompanyTier =
  | 'MAANG / Tier-1 Global Product'
  | 'Indian Tech Unicorn / Decacorn'
  | 'Global Capability Center (GCC India)'
  | 'High-Growth AI / SaaS Startup'
  | 'Enterprise IT & Digital Consulting';

export type MLModelType =
  | 'Stacked Meta-Ensemble'
  | 'Gradient Boosting (GBDT)'
  | 'Random Forest Regressor'
  | 'L2 Ridge Regression';

export interface CandidateProfile {
  employmentStatus: EmploymentStatus;
  role: string;
  customRoleTitle: string;
  category: RoleCategory;
  customComplexity: number;
  experienceYears: number;
  educationLevel: EducationLevel;
  locationTier: LocationTier;
  indianCity: IndianCity;
  companyTier: CompanyTier;
  mlModel: MLModelType;
  skills: string[];
  stressTestAnomaly: boolean;
}

export interface MLEnsembleComparisonItem {
  modelName: MLModelType | string;
  predictedInr: number;
  r2Score: number;
  rmseLog: number;
  architecture: string;
}

export interface IndianTaxBreakdown {
  annualCtcInr: number;
  annualBaseInr: number;
  annualBonusInr: number;
  annualEquityInr: number;
  annualEpfInr: number;
  annualIncomeTaxInr: number;
  monthlyInHandInr: number;
  effectiveTaxRatePct: number;
}

export interface RealLifeAverageBreakdown {
  averageEstimatedOutcomeInr: number;
  massMarketMedianInr: number;
  gccProductBenchmarkInr: number;
  mlEnsembleMeanInr: number;
  tierAdjustedInr: number;
  realisticLowInr: number;
  realisticHighInr: number;
}

export interface SessionOutcomeEntry {
  timestamp: string;
  role: string;
  indianCity: string;
  employmentStatus: string;
  experienceYears: number;
  companyTier: string;
  mlModel: string;
  estimatedCtcInr: number;
  monthlyInHandInr: number;
}

export interface SessionOutcomeTelemetry {
  sessionSimulationCount: number;
  sessionAverageCtcInr: number;
  sessionAverageMonthlyInHandInr: number;
  sessionMinCtcInr: number;
  sessionMaxCtcInr: number;
  allIndiaTechMedianBenchmarkInr: number;
  sessionHistory: SessionOutcomeEntry[];
}

export interface RegressionResult {
  engine: string;
  selectedMlModel: string;
  effectiveRole: string;
  category: string;
  indianCity: string;
  isStudent: boolean;
  effectiveExperienceYears: number;
  rawRegressionInr: number;
  calibratedBaselineInr: number;
  stressTestActive: boolean;
  realLifeAverageBreakdown?: RealLifeAverageBreakdown;
  sessionOutcomeTelemetry?: SessionOutcomeTelemetry;
  fxTelemetry?: {
    updatedAt: string;
    isLiveFeed: boolean;
    usdToInr: number;
  };
  mlEnsembleComparison?: MLEnsembleComparisonItem[];
  indianTaxBreakdown?: IndianTaxBreakdown;
  modelMetrics: {
    r2Score: number;
    rmseLog: number;
    trainingRecordsCount: number;
    currenciesNormalized: number;
  };
  percentileBandsInr: {
    p10: number;
    p25: number;
    p50: number;
    p75: number;
    p90: number;
  };
  componentSplit: {
    basePct: number;
    bonusPct: number;
    equityPct: number;
  };
  featureAttributionInr: {
    roleBaseAnchor: number;
    experiencePremium: number;
    skillsArbitrage: number;
    locationMarketAdjustment: number;
    educationCredentialDelta: number;
  };
  multiCurrencyParity: Record<string, number>;
  fxRatesToInr: Record<string, number>;
}

export interface SkillArbitrageItem {
  skillName: string;
  estimatedInrUplift: number;
  upliftPercentage: number;
  marketRationale: string;
}

export interface CareerStageItem {
  horizon: string;
  targetRole: string;
  projectedInr: number;
  deltaInr: number;
  coreSkillsToAcquire: string[];
  concreteDeliverable: string;
}

export interface LLMValidationResult {
  validationStatus: 'VERIFIED_MARKET_ALIGNED' | 'INTERCEPTED_AND_CORRECTED' | string;
  validationCode: string;
  isIntercepted: boolean;
  rawRegressionInr: number;
  validatedInr: number;
  correctionDeltaInr: number;
  confidenceScore: number;
  validationReasoning: string;
  marketPositioning: string;
  executiveNegotiationLever: string;
  skillArbitrage: SkillArbitrageItem[];
  careerRoadmap: CareerStageItem[];
  llmSource: string;
}

export interface PredictionResponse {
  regression: RegressionResult;
  llmValidation: LLMValidationResult;
}

export interface LiveMarketPulseResponse {
  summary: string;
  hiringDemandIndex: string;
  topPayingRecruitersIndia: string[];
  sources: { title: string; uri: string }[];
  timestamp: string;
}

export interface DatasetRecord {
  record_id: string;
  role: string;
  category: string;
  experience_years: number;
  education_level: string;
  employment_status: string;
  location_tier: string;
  indian_city?: string;
  currency: string;
  raw_annual_salary: number;
  fx_rate_to_inr: number;
  converted_inr: number;
  ppp_calibrated_inr?: number;
  ppp_factor?: number;
  equity_pct: number;
  bonus_pct: number;
  primary_skills: string[];
  company_tier: string;
  data_source?: string;
}

export const ROLE_CATALOG_BY_CATEGORY: Record<RoleCategory, string[]> = {
  'AI & Data Science': [
    'Principal AI Architect',
    'Machine Learning Engineer',
    'AI Research Scientist',
    'NLP / LLM Systems Engineer',
    'Data Scientist',
    'Data Engineering Lead',
    'Computer Vision Engineer',
  ],
  'Core Software & Cloud': [
    'Staff Software Engineer',
    'Backend Systems Engineer',
    'Full-Stack Engineer',
    'Cloud Infrastructure Architect',
    'Site Reliability Engineer',
    'Mobile Platform Architect',
    'Enterprise Solutions Architect',
  ],
  'Quant & Fintech': [
    'Quantitative Researcher',
    'Quantitative Developer',
    'Blockchain Protocol Engineer',
    'Fintech Risk Modeling Lead',
  ],
  'Cybersecurity & Infrastructure': [
    'Principal Security Architect',
    'DevSecOps / SRE Lead',
    'Cybersecurity Analyst',
  ],
  'Product & Design': [
    'Group Product Manager (AI)',
    'Staff Product Designer',
  ],
  'Executive Leadership': [
    'Chief AI Officer (CAIO)',
    'VP of Engineering',
    'Director of Platform Engineering',
  ],
};

export interface SkillCatalogEntry {
  name: string;
  premiumPct: number;
  category: RoleCategory;
}

export const SKILL_CATALOG: SkillCatalogEntry[] = [
  { name: 'PyTorch', premiumPct: 4.8, category: 'AI & Data Science' },
  { name: 'LLM Fine-Tuning', premiumPct: 6.8, category: 'AI & Data Science' },
  { name: 'RAG', premiumPct: 5.5, category: 'AI & Data Science' },
  { name: 'CUDA', premiumPct: 6.5, category: 'AI & Data Science' },
  { name: 'Transformers', premiumPct: 5.2, category: 'AI & Data Science' },
  { name: 'MLOps', premiumPct: 4.5, category: 'AI & Data Science' },
  { name: 'Python', premiumPct: 2.8, category: 'AI & Data Science' },
  { name: 'Spark', premiumPct: 4.2, category: 'AI & Data Science' },
  { name: 'Distributed Systems', premiumPct: 6.2, category: 'Core Software & Cloud' },
  { name: 'Kubernetes', premiumPct: 4.5, category: 'Core Software & Cloud' },
  { name: 'Go', premiumPct: 4.8, category: 'Core Software & Cloud' },
  { name: 'Rust', premiumPct: 6.0, category: 'Core Software & Cloud' },
  { name: 'TypeScript', premiumPct: 3.2, category: 'Core Software & Cloud' },
  { name: 'React', premiumPct: 2.8, category: 'Core Software & Cloud' },
  { name: 'AWS', premiumPct: 3.5, category: 'Core Software & Cloud' },
  { name: 'Kafka', premiumPct: 4.2, category: 'Core Software & Cloud' },
  { name: 'Stochastic Calculus', premiumPct: 7.0, category: 'Quant & Fintech' },
  { name: 'Low-Latency', premiumPct: 6.2, category: 'Quant & Fintech' },
  { name: 'C++', premiumPct: 5.2, category: 'Quant & Fintech' },
  { name: 'Solidity', premiumPct: 4.8, category: 'Quant & Fintech' },
  { name: 'Zero-Trust', premiumPct: 4.8, category: 'Cybersecurity & Infrastructure' },
  { name: 'Terraform', premiumPct: 3.8, category: 'Cybersecurity & Infrastructure' },
  { name: 'Linux Kernel', premiumPct: 5.5, category: 'Cybersecurity & Infrastructure' },
  { name: 'System Architecture', premiumPct: 6.0, category: 'Executive Leadership' },
  { name: 'Foundation Models', premiumPct: 6.8, category: 'Executive Leadership' },
  { name: 'Cloud FinOps', premiumPct: 4.2, category: 'Executive Leadership' },
  { name: 'Product Strategy', premiumPct: 3.8, category: 'Product & Design' },
  { name: 'Design Systems', premiumPct: 3.5, category: 'Product & Design' },
];

export const CURRENCY_SYMBOLS: Record<string, string> = {
  INR: '₹',
  USD: '$',
  EUR: '€',
  GBP: '£',
  SGD: 'S$',
  AED: 'AED ',
  CHF: 'CHF ',
  CAD: 'C$',
  AUD: 'A$',
  JPY: '¥',
};

export function formatInrCompact(amountInr: number): string {
  const abs = Math.abs(amountInr);
  const sign = amountInr < 0 ? '-' : '';
  if (abs >= 10000000) {
    return `${sign}₹${(abs / 10000000).toFixed(2)} Cr`;
  }
  if (abs >= 100000) {
    return `${sign}₹${(abs / 100000).toFixed(2)} L`;
  }
  return `${sign}₹${Math.round(abs).toLocaleString('en-IN')}`;
}

export function formatInrExact(amountInr: number): string {
  const sign = amountInr < 0 ? '-' : '';
  return `${sign}₹${Math.round(Math.abs(amountInr)).toLocaleString('en-IN')}`;
}

export function formatSovereignCurrency(amount: number, currency: string): string {
  const sym = CURRENCY_SYMBOLS[currency] || `${currency} `;
  if (currency === 'INR') {
    return formatInrExact(amount);
  }
  return `${sym}${Math.round(amount).toLocaleString('en-US')}`;
}
